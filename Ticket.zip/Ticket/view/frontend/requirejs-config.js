var config = {
    map: {
        'owl.carousel': 'Magenest_Ticket/js/owl.carousel'
    },
    shim: {
        'Magenest_Ticket/js/owl.carousel':{
            'deps':['jquery']
        }
    },
    // paths:{
    //     'fullCalendar':'https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.2.0/fullcalendar.min.js'
    // }
};
