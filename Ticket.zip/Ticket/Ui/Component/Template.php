<?php

namespace Movie\Ticket\Ui\Component;

use Movie\Ticket\Model\TemplateFactory;
use Magento\Framework\Option\ArrayInterface;

/**
 * Class Template
 * @package Movie\Ticket\Ui\Component
 */
class Template implements ArrayInterface
{
    /**
     * @var
     */
    protected $template;

    /**
     * Template constructor.
     * @param TemplateFactory $template
     */
    public function __construct(
        TemplateFactory $template
    ) {
        $this->template = $template;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $model = $this->template->create()->getCollection();
        $result = array();
        foreach ($model as $temp) {
            $array = [
                'label' => $temp->getTitle(),
                'value' => $temp->getTemplateId()
            ];
            array_push($result, $array);
        }

        return $result;
    }
}
