<?php
namespace Movie\Ticket\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Ui\Component\Listing\Columns\Column;
use Movie\Ticket\Model\DateSessionFactory;

class TicketSession extends Column
{
    /**
     * @var SessionFactory
     */
    protected $_sessionFactory;

    /**
     * TicketSession constructor.
     * @param DateSessionFactory $sessionFactory
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param array $components
     * @param array $data
     */
    public function __construct(
        DateSessionFactory $sessionFactory,
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        array $components = [],
        array $data = [])
    {
        $this->_sessionFactory = $sessionFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$items) {
                if (!empty($items['session'])) {
                    $start            = $this->_sessionFactory->create()->load($items['session'])->getTime();
                    $items['session'] = $start;
                }
                else $items['session'] = '';
            }
        }

        return $dataSource;
    }
}