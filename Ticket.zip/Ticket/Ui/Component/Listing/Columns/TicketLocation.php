<?php

namespace Movie\Ticket\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Ui\Component\Listing\Columns\Column;
use Movie\Ticket\Model\RoomFactory;

class TicketLocation extends Column
{
    /**
     * @var LocationFactory
     */
    protected $_locationFactory;
    protected $_roomFactory;
    /**
     * TicketLocation constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param array $components
     * @param array $data
     */
    public function __construct(
        RoomFactory $roomFactory,
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        array $components = [],
        array $data = [])
    {
        $this->_roomFactory=$roomFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$items) {
                if (isset($items['room'])) {
                    $items['room'] = $this->_roomFactory->create()->load($items['room'])->getCinemaId();
                }
            }
        }
        return $dataSource;
    }
}