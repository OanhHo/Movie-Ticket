<?php
namespace Movie\Ticket\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Ui\Component\Listing\Columns\Column;
use Movie\Ticket\Model\DateFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * Class TicketDate
 * @package Movie\Ticket\Ui\Component\Listing\Columns
 */
class TicketDate extends Column
{
    /**
     * Date format
     */
    const XML_PATH_DATE_FORMAT = 'event_ticket/general_config/date_format';

    /**
     * @var DateFactory
     */
    protected $dateFactory;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * TicketDate constructor.
     * @param ScopeConfigInterface $scopeConfig
     * @param DateFactory $dateFactory
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        DateFactory $dateFactory,
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        array $components = [],
        array $data = [])
    {
        $this->scopeConfig = $scopeConfig;
        $this->dateFactory = $dateFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        $dateFormat = $this->scopeConfig->getValue(self::XML_PATH_DATE_FORMAT);
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$items) {
                if (!empty($items['date'])) {
                    $date = $this->dateFactory->create()->load($items['date'])->getDate();
                    $ticketDate = trim(date($dateFormat, strtotime($date)));
                    $items['date'] = $ticketDate;
                } else $items['date'] = '';
            }
        }
        return $dataSource;
    }
}