<?php
namespace Movie\Ticket\Ui\Component\Room\Detail;

/**
 * Class Options
 * @package Movie\Ticket\Ui\Component\Room\Detail
 */
class Options implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => __('A'), 'value' => 'A'],
            ['label' => __('B'), 'value' => 'B'],
            ['label' => __('C '), 'value' => 'C'],
            ['label' => __('D'), 'value' => 'D'],
            ['label' => __('E'), 'value' => 'E'],
            ['label' => __('F'), 'value' => 'F'],
            ['label' => __('G'), 'value' => 'G'],
            ['label' => __('H'), 'value' => 'H'],
            ['label' => __('I'), 'value' => 'I'],
            ['label' => __('K'), 'value' => 'K'],
            ['label' => __('L'), 'value' => 'L'],
            ['label' => __('M'), 'value' => 'M'],
            ['label' => __('N'), 'value' => 'N']
        ];
    }
}
