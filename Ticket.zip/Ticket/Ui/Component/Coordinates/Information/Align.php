<?php

namespace Movie\Ticket\Ui\Component\Coordinates\Information;

/**
 * Class Align
 * @package Movie\Ticket\Ui\Component\Coordinates\Information
 */
class Align implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => __('--------'), 'value' => null],
            ['label' => __('Left'), 'value' => 'left'],
            ['label' => __('Center'), 'value' => 'center'],
            ['label' => __('Right'), 'value' => 'right'],
        ];
    }
}
