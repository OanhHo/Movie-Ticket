<?php

namespace Movie\Ticket\Ui\Component\Coordinates\Information;

/**
 * Class Format
 * @package Movie\Ticket\Ui\Component\Coordinates\Information
 */
class Format implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => __('--------'), 'value' => null],
            ['label' => __('Regular'), 'value' => 'regular'],
            ['label' => __('Bold'), 'value' => 'bold'],
            ['label' => __('Italic'), 'value' => 'italic'],
            ['label' => __('Bold & Italic'), 'value' => 'bold_italic'],

        ];
    }
}
