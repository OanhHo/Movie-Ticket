<?php

namespace Movie\Ticket\Ui\Component\Coordinates\Information;

/**
 * Class Color
 * @package Movie\Ticket\Ui\Component\Coordinates\Information
 */
class Color implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => __('Black'), 'value' => 'black'],
            ['label' => __('Red'), 'value' => 'red'],
            ['label' => __('Yellow'), 'value' => 'yellow'],
            ['label' => __('Blue'), 'value' => 'blue'],
            ['label' => __('Green'), 'value' => 'green']
        ];
    }
}
