<?php
namespace Movie\Ticket\Ui\Component\Coordinates\Information;

/**
 * Class Options
 * @package Movie\Ticket\Ui\Component\Coordinates\Information
 */
class Options implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => __('Film Name'), 'value' => 'film_name'],
            ['label' => __('Film Photo'), 'value' => 'film_photo'],
            ['label' => __('Location '), 'value' => 'location'],
            ['label' => __('QR Code'), 'value' => 'qr_code'],
            ['label' => __('Bar Code'), 'value' => 'bar_code'],
            ['label' => __('Code'), 'value' => 'code'],
            ['label' => __('Date'), 'value' => 'date'],
            ['label' => __('Start Time'), 'value' => 'start_time'],
            ['label' => __('End Time'), 'value' => 'end_time'],
            ['label' => __('Customer Name'), 'value' => 'customer_name'],
            ['label' => __('Customer Email'), 'value' => 'customer_email'],
            ['label' => __('Order #'), 'value' => 'order_increment_id'],
            ['label' => __('Quantity'), 'value' => 'qty']
        ];
    }
}
