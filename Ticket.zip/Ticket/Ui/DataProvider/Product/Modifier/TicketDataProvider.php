<?php

namespace Movie\Ticket\Ui\DataProvider\Product\Modifier;

use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;
use Magento\Framework\App\RequestInterface;
use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\Framework\Serialize\Serializer\Serialize;
use Movie\Ticket\Model\FilmFactory;
use Movie\Ticket\Model\RoomFactory;
use Movie\Ticket\Model\CinemaFactory;
use Movie\Ticket\Model\DateFactory;
use Movie\Ticket\Model\DateSessionFactory;
/**
 * Class TicketDataProvider
 * @package Movie\Ticket\Ui\DataProvider\Product\Modifier
 */
class TicketDataProvider extends AbstractModifier
{
    const PRODUCT_TYPE                   = 'film';
    const CONTROLLER_ACTION_EDIT_PRODUCT = 'catalog_product_edit';
    const CONTROLLER_ACTION_NEW_PRODUCT  = 'catalog_product_new';
    const EVENT_TICKET_TAB               = 'film';

    /**
     * @var array
     */
    protected $meta = [];

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var LocatorInterface
     */
    protected $locator;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @var Serialize
     */
    protected $serialize;
    /**
     * @var FilmFactory
     */
    protected $_filmFactory;
    /**
     * @var RoomFactory
     */
    protected $_roomFactory;
    /**
     * @var DateFactory
     */
    protected $_dateFactory;
    /**
     * @var CinemaFactory
     */
    protected $_cinemaFactory;
    protected $_json;
    /**
     * @var DateSessionFactory
     */
    protected $_dateSessionFactory;

    /**
     * TicketDataProvider constructor.
     * @param RequestInterface $request
     * @param LocatorInterface $locator
     * @param Serialize $serialize
     * @param FilmFactory $filmFactory
     * @param \Psr\Log\LoggerInterface $loggerInterface
     * @param RoomFactory $roomFactory
     * @param CinemaFactory $cinemaFactory
     * @param DateFactory $dateFactory
     * @param DateSessionFactory $dateSessionFactory
     */
    public function __construct(
        RequestInterface $request,
        LocatorInterface $locator,
        Serialize $serialize,
        FilmFactory $filmFactory,
        \Psr\Log\LoggerInterface $loggerInterface,
        RoomFactory $roomFactory,
        CinemaFactory $cinemaFactory,
        DateFactory $dateFactory,
        DateSessionFactory $dateSessionFactory
    ) {
        $this->logger            = $loggerInterface;
        $this->serialize         = $serialize;
        $this->_filmFactory      = $filmFactory;
        $this->_roomFactory      = $roomFactory;
        $this->request           = $request;
        $this->locator           = $locator;
        $this->_cinemaFactory    = $cinemaFactory;
        $this->_dateFactory      = $dateFactory;
        $this->_dateSessionFactory=$dateSessionFactory;
    }

    /**
     * @param array $data
     *
     * @return array
     */
    public function modifyData(array $data)
    {
        $product   = $this->locator->getProduct();
        $productId = $product->getId();
        if ($this->isFilmTicket()) {
            $filmModle = $this->_filmFactory->create()->getCollection()
                ->addFieldToFilter('product_id', $productId)
                ->getFirstItem();
            if ($filmModle) {
                //data on pdftemplate
                $data[strval($productId)]['film']['pdftemplate'] = [
                    'use_custom_template' => $filmModle->getUseCustomerTemplate(),
                    'template_id'         => $filmModle->getTemplateId(),
                ];

                $data[$productId]['film']['genre']       = $filmModle->getGenre();
                $data[$productId]['film']['cast'] = $filmModle->getCast();
                $data[$productId]['film']['director'] = $filmModle->getDirector();
                $data[$productId]['film']['in_theater'] = $filmModle->getInTheater();
                $data[$productId]['film']['runtime'] = $filmModle->getRuntime();
                $data[$productId]['film']['rated'] = $filmModle->getRated();
                $data[$productId]['film']['detail'] = $filmModle->getDetail();
                $data[$productId]['film']['trailer'] = $filmModle->getTrailer();
                $modelSession = $this->_dateSessionFactory->create()->getCollection()->addFieldToFilter('product_id', $productId);
                $arraySession=[];
                $counter=0;
                foreach ($modelSession as $session) {
                    $modelRoom=$this->_roomFactory->create()->getCollection()
                        ->addFieldToFilter('room_id',$session->getRoomId())
                        ->getFirstItem();
                    $modelCinema=$this->_cinemaFactory->create()->getCollection()
                        ->addFieldToFilter('cinema_id',$modelRoom->getCinemaId())
                        ->getFirstItem();
                    $data[strval($productId)]['film']['date-session']['session'][$counter]    = [
                        'session_id'         => $session->getSessionId(),
                        'record_id'    => $counter,
                        'info' => "Cinema: ".$modelCinema->getName()." - Room: ".$modelRoom->getTitle()." - Date: ".$session->getDate()." - DateSession: ".$session->getTime(),
                        'qty'=>$session->getQty(),
                        'qty_purchase'=>$session->getQtyPurchase(),
                        'session_is_enabled'=>$session->getSessionIsEnabled()
                    ];
                    $counter++;
//                    $arraySession [] = $sessionArray;
                }
                //data on schedule
//                $data[strval($productId)]['film']['date-session']['session'] = $arraySession;
                $data[strval($productId)]['film']['terms-conditions']['term'] = $filmModle->getTerm();
                $data[strval($productId)]['film']['apply_all_schedule']       = $filmModle->getApplyAllSchedule();
            }
        }

        return $data;
    }

    /**
     * @param array $meta
     *
     * @return array
     */
    public function modifyMeta(array $meta)
    {
        if (!$this->isFilmTicket()) {
            $meta['film']['arguments']['data']['config'] = [
                'disabled' => true,
                'visible'  => false
            ];
        }

        return $meta;
    }

    /**
     * @return bool
     */
    protected function isFilmTicket()
    {
        $actionName    = $this->request->getFullActionName();
        $isFilmTicket = false;
        if ($actionName == self::CONTROLLER_ACTION_EDIT_PRODUCT) {
            /** @var \Magento\Catalog\Model\Product $product */
            $product = $this->locator->getProduct();
            if ($product->getTypeId() == self::PRODUCT_TYPE) {
                $isFilmTicket = true;
            }
        } elseif ($actionName == self::CONTROLLER_ACTION_NEW_PRODUCT) {
            if (self::PRODUCT_TYPE == $this->request->getParam('type')) {
                $isFilmTicket = true;
            }
        }

        return $isFilmTicket;
    }
}
