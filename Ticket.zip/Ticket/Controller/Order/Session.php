<?php
namespace Movie\Ticket\Controller\Order;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Movie\Ticket\Model\DateSessionFactory;
use Movie\Ticket\Model\RoomFactory;
use Movie\Ticket\Model\CinemaFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Psr\Log\LoggerInterface;

/**
 * Class Session
 * @package Movie\Ticket\Controller\Order
 */
class Session extends Action
{
    const XML_PATH_MAP_ENABLED = 'movie_ticket/general_config/google_map';

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var DateSessionFactory
     */
    protected $session;
    /**
     * @var RoomFactory
     */
    protected $room;
    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;
    /**
     * @var CinemaFactory
     */
    protected $cinema;
    /**
     * Session constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param LoggerInterface $loggerInterface
     * @param DateSessionFactory $dateSessionFactory
     * @param RoomFactory $roomFactory
     * @param ScopeConfigInterface $scopeConfig
     * @param CinemaFactory $cinemaFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        LoggerInterface $loggerInterface,
        DateSessionFactory $dateSessionFactory,
        RoomFactory $roomFactory,
        ScopeConfigInterface $scopeConfig,
        CinemaFactory $cinemaFactory
    ) {
        $this->session = $dateSessionFactory;
        $this->room=$roomFactory;
        $this->logger = $loggerInterface;
        $this->resultPageFactory = $resultPageFactory;
        $this->_scopeConfig      = $scopeConfig;
        $this->cinema=$cinemaFactory;
        parent::__construct($context);
    }

    /**
     * View my ticket
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $params = $this->getRequest()->getParams();
        $cinemaId = $params['cinema_id'];
        $cinema=$this->cinema->create()->getCollection()
            ->addFieldToFilter('cinema_id',$cinemaId)
            ->getFirstItem();
        $modelSession = $this->session->create()->getCollection()->addFieldToFilter('cinema_id', $cinemaId);
        $arraySession = [];
        if (!empty($modelSession->getData())) {
            foreach ($modelSession as $session) {
                /**
                 * @param \Moive\Ticket\Model\DateSession $session
                 * check session is enable and qty 07/01/2020
                 */
                $sessionIsEnable=$session->getSessionIsEnabled();
                if ($sessionIsEnable == 1) {
                    $room=$this->room->create()->getCollection()
                        ->addFieldToFilter('room_id',$session->getRoomId())
                        ->getFirstItem();
                    $array = [
                        'session_id' => $session->getSessionId(),
                        'room' => $room->getTitle(),
                        'cinema_id'=>$room->getCinemaId(),
                        'date'=> $session->getDate(),
                        'time' =>$session->getTime(),
                        'qty'=>$session->getQty(),
                        'qty_purchase'=>$session->getQtyPurchase()
                    ];
                    $arraySession [] = $array;
                }
            }
        }
        $array1['session_data']     = $arraySession;
        $array2['location_data'] = $cinema->getName() . ', ' . $cinema->getAddress();
        $array3['map_enabled']   = $this->_scopeConfig->getValue(self::XML_PATH_MAP_ENABLED);
        $arrayResult             = array_merge($array1, $array2,$array3);
        $resultArray = json_encode($arrayResult);
        $resultJson = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_JSON);
        $resultJson->setData($resultArray);

        return $resultJson;
    }
}
