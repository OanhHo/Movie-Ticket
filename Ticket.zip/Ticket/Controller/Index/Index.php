<?php
namespace Movie\Ticket\Controller\Index;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Framework\App\Action\Action{

    protected $_resultPage;
    public function __construct(Context $context,PageFactory $resultPage)
    {
        $this->_resultPage=$resultPage;
        parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $this->_view->loadLayout();
        if ($block = $this->_view->getLayout()->getBlock('movie')) {
            $block->setRefererUrl($this->_redirect->getRefererUrl());
        }
        $this->_view->getPage()->getConfig()->getTitle()->set( 'Movie');

        $this->_view->renderLayout();
    }
}
