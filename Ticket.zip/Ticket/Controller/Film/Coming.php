<?php
namespace Movie\Ticket\Controller\Film;

use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * Class Coming
 * @package Movie\Ticket\Controller\Film
 */
class Coming extends \Magento\Framework\App\Action\Action
{
    protected $_configInterface;
    /**
     * View constructor.
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(\Magento\Framework\App\Action\Context $context,
                                ScopeConfigInterface $configInterface
    ) {
        $this->_configInterface=$configInterface;
        parent::__construct($context);
    }

    public function execute()
    {
        $this->_view->loadLayout();
        if ($block = $this->_view->getLayout()->getBlock('coming_soon_fullcalendar_view')) {
            $block->setRefererUrl($this->_redirect->getRefererUrl());
        }
        $this->_view->getPage()->getConfig()->getTitle()->set(__('Coming Soon'));
        $this->_view->renderLayout();
    }
}
