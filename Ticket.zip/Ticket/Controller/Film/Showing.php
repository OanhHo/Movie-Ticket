<?php
namespace Movie\Ticket\Controller\Film;

use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * Class Showing
 * @package Movie\Ticket\Controller\Film
 */
class Showing extends \Magento\Framework\App\Action\Action
{
    protected $_configInterface;
    /**
     * View constructor.
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(\Magento\Framework\App\Action\Context $context,
                                ScopeConfigInterface $configInterface
    ) {
        $this->_configInterface=$configInterface;
        parent::__construct($context);
    }

    public function execute()
    {
        $this->_view->loadLayout();
        if ($block = $this->_view->getLayout()->getBlock('showing_fullcalendar_view')) {
            $block->setRefererUrl($this->_redirect->getRefererUrl());
        }
        $this->_view->getPage()->getConfig()->getTitle()->set(__('Showing'));
        $this->_view->renderLayout();
    }
}
