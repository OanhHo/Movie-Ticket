<?php
namespace Movie\Ticket\Controller\Film;

use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * Class View
 * @package Magenest\Ticket\Controller\Event
 */
class Index extends \Magento\Framework\App\Action\Action
{
    protected $_configInterface;
    /**
     * View constructor.
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(\Magento\Framework\App\Action\Context $context,
                                ScopeConfigInterface $configInterface
    ) {
        $this->_configInterface=$configInterface;
        parent::__construct($context);
    }

    public function execute()
    {
        $this->_view->loadLayout();
        if ($block = $this->_view->getLayout()->getBlock('event_fullcalendar_view')) {
            $block->setRefererUrl($this->_redirect->getRefererUrl());
        }
        $evnet_name=$this->_configInterface->getValue('event_ticket/event_header_link_config/event_name');
        $evnet_name ? $this->_view->getPage()->getConfig()->getTitle()->set(__($evnet_name.' Calendar')) : $this->_view->getPage()->getConfig()->getTitle()->set(__('Events Calendar'));

        $this->_view->renderLayout();
    }
}
