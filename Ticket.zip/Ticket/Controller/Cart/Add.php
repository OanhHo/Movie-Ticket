<?php

namespace Movie\Ticket\Controller\Cart;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Checkout\Model\Cart as CustomerCart;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Registry;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Serialize\Serializer\Json;
use Movie\Ticket\Helper\Film;

/**
 * Class Add
 * @package Movie\Ticket\Controller\Cart
 */
class Add extends \Magento\Checkout\Controller\Cart\Add
{
    /**
     * Core registry
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * Date format
     */
    const XML_PATH_DATE_FORMAT = 'movie_ticket/general_config/date_format';
    /**
     * @var \Movie\Ticket\Model\CinemaFactory
     */
   protected $cinema;

    /**
     * @var \Movie\Ticket\Model\RoomFactory
     */
   protected $room;

    /**
     * @var \Movie\Ticket\Model\DateFactory
     */
   protected $date;

    /**
     * @var \Movie\Ticket\Model\DateSessionFactory
     */
   protected $session;

    /**
     * @var Film
     */
   protected $_filmHelper;
    /**
     * @var Json
     */
    protected $serialize;

    /**
     * Add constructor.
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     * @param Session $checkoutSession
     * @param StoreManagerInterface $storeManager
     * @param Validator $formKeyValidator
     * @param CustomerCart $cart
     * @param ProductRepositoryInterface $productRepository
     * @param Film $film
     * @param Registry $coreRegistry
     * @param Json $serialize
     * @param \Movie\Ticket\Model\CinemaFactory $cinemaFactory
     * @param \Movie\Ticket\Model\RoomFactory $roomFactory
     * @param \Movie\Ticket\Model\DateFactory $dateFactory
     * @param \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        Session $checkoutSession,
        StoreManagerInterface $storeManager,
        Validator $formKeyValidator,
        CustomerCart $cart,
        ProductRepositoryInterface $productRepository,
        Film $film,
        Registry $coreRegistry,
        Json $serialize,
        \Movie\Ticket\Model\CinemaFactory $cinemaFactory,
        \Movie\Ticket\Model\RoomFactory $roomFactory,
        \Movie\Ticket\Model\DateFactory $dateFactory,
        \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory
    ) {
        $this->cinema    = $cinemaFactory;
        $this->room      = $roomFactory;
        $this->date          = $dateFactory;
        $this->session       = $dateSessionFactory;
        $this->_coreRegistry = $coreRegistry;
        $this->serialize     = $serialize;
        $this->_filmHelper  = $film;
        parent::__construct(
            $context,
            $scopeConfig,
            $checkoutSession,
            $storeManager,
            $formKeyValidator,
            $cart,
            $productRepository
        );
    }

    /**
     * Add product to shopping cart action
     * @return \Magento\Framework\Controller\Result\Redirect
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function execute()
    {
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }

        $params             = $this->getRequest()->getParams();
        $productInformation = $this->_initProduct();
        if ($productInformation->getTypeId() === 'film') {
            $this->productRepository->cleanCache();
            $this->cart->getQuote()->setTotalsCollectedFlag(false);
            foreach ($this->cart->getQuote()->getAllAddresses() as $address) {
                $address->unsetData('cached_items_all');
            }
            $ticketParams = $params;
            try {
                if (isset($ticketParams['qty'])) {
                    $filter              = new \Zend_Filter_LocalizedToNormalized(
                        [
                            'locale' => $this->_objectManager->get(
                                \Magento\Framework\Locale\ResolverInterface::class
                            )->getLocale()
                        ]
                    );
                    $ticketParams['qty'] = $filter->filter($ticketParams['qty']);
                }

                $product = clone $this->_initProduct();
                if (isset($ticketParams['additional_options'])) {
                    $customerOptions = $this->generateCustomerOptions($ticketParams);
                } else {
                    $this->messageManager->addNotice(__('You need to choose options for your item.'));

                    return $this->goBack($product->getUrlInStore());
                }
                if (!empty($customerOptions)) {
                    $product->addCustomOption('additional_options', $customerOptions);
                }
                $related = $this->getRequest()->getParam('related_product');

                /**
                 * Check product availability
                 */
                if (!$product) {
                    return $this->goBack();
                }

                $this->cart->addProduct($product, $ticketParams);
                if (!empty($related)) {
                    $this->cart->addProductsByIds($related);
                }

                /**
                 * @todo remove wishlist observer \Magento\Wishlist\Observer\AddToCart
                 */
                $this->_eventManager->dispatch(
                    'checkout_cart_add_product_complete',
                    ['product' => $product, 'request' => $this->getRequest(), 'response' => $this->getResponse()]
                );

                if (!$this->_checkoutSession->getNoCartRedirect(true)) {
                    if (!$this->cart->getQuote()->getHasError()) {
                        $message = __(
                            'You added %1 to your shopping cart.',
                            $product->getName()
                        );
                        $this->messageManager->addSuccessMessage($message);
                    }
                }
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                if ($this->_checkoutSession->getUseNotice(true)) {
                    $this->messageManager->addNotice(
                        $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml($e->getMessage())
                    );
                } else {
                    $messages = array_unique(explode("\n", $e->getMessage()));
                    foreach ($messages as $message) {
                        $this->messageManager->addError(
                            $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml($message)
                        );
                    }
                }

                $url = $this->_checkoutSession->getRedirectUrl(true);

                if (!$url) {
                    $cartUrl = $this->_objectManager->get(\Magento\Checkout\Helper\Cart::class)->getCartUrl();
                    $url     = $this->_redirect->getRedirectUrl($cartUrl);
                }

                return $this->goBack($url);
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('We can\'t add this item to your shopping cart right now.'));
                $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);

                return $this->goBack();
            }


            $this->cart->save();
            if (isset($product)) {
                return $this->goBack(null, $product);
            } else {
                return $this->goBack(null, $this->_initProduct());
            }
        } else {
            try {
                if (isset($params['qty'])) {
                    $filter        = new \Zend_Filter_LocalizedToNormalized(
                        [
                            'locale' => $this->_objectManager->get(
                                \Magento\Framework\Locale\ResolverInterface::class
                            )->getLocale()
                        ]
                    );
                    $params['qty'] = $filter->filter($params['qty']);
                }

                $product = $this->_initProduct();
                $related = $this->getRequest()->getParam('related_product');

                /**
                 * Check product availability
                 */
                if (!$product) {
                    return $this->goBack();
                }

                $this->cart->addProduct($product, $params);
                if (!empty($related)) {
                    $this->cart->addProductsByIds(explode(',', $related));
                }

                $this->cart->save();

                /**
                 * @todo remove wishlist observer \Magento\Wishlist\Observer\AddToCart
                 */
                $this->_eventManager->dispatch(
                    'checkout_cart_add_product_complete',
                    ['product' => $product, 'request' => $this->getRequest(), 'response' => $this->getResponse()]
                );

                if (!$this->_checkoutSession->getNoCartRedirect(true)) {
                    if (!$this->cart->getQuote()->getHasError()) {
                        $message = __(
                            'You added %1 to your shopping cart.',
                            $product->getName()
                        );
                        $this->messageManager->addSuccessMessage($message);
                    }

                    return $this->goBack(null, $product);
                }
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                if ($this->_checkoutSession->getUseNotice(true)) {
                    $this->messageManager->addNotice(
                        $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml($e->getMessage())
                    );
                } else {
                    $messages = array_unique(explode("\n", $e->getMessage()));
                    foreach ($messages as $message) {
                        $this->messageManager->addError(
                            $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml($message)
                        );
                    }
                }

                $url = $this->_checkoutSession->getRedirectUrl(true);

                if (!$url) {
                    $cartUrl = $this->_objectManager->get(\Magento\Checkout\Helper\Cart::class)->getCartUrl();
                    $url     = $this->_redirect->getRedirectUrl($cartUrl);
                }

                return $this->goBack($url);
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('We can\'t add this item to your shopping cart right now.'));
                $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);

                return $this->goBack();
            }
        }
    }

//    }

    /**
     * @param $ticketParams
     * @param $productId
     *
     * @return string
     */
    private function generateCustomerOptions($ticketParams)
    {
        $options           = $ticketParams['additional_options'];
        $additionalOptions = [];
        $cinemaId = '';
        $sessionId  = '';
        if (isset($options['single']) && !empty($options['single'])) {
            if (!empty($options['single']['ticket_location'])) {
                $cinemaId = $options['single']['ticket_location'];
            }
            if (!empty($options['single']['ticket_session'])) {
                $sessionId = $options['single']['ticket_session'];
            }
        } else {
            if (isset($options['ticket_location']) && !empty($options['ticket_location'])) {
                $cinemaId = $options['ticket_location'];
            }

            if (isset($options['ticket_session']) && !empty($options['ticket_session'])) {
                $sessionId = $options['ticket_session'];
            }
        }

        if (!empty($cinemaId)) {
            $cinema = $this->cinema->create()->load($cinemaId);

            $additionalOptions[] = [
                'label' => 'Cinema',
                'value' => $cinema->getName()
            ];
        }
        if (!empty($sessionId)) {
            $session   = $this->session->create()->load($sessionId);
            $startTime = '';
            if (!empty($session->getTime())) {
                $startTime = 'Start: ' . $session->getTime() . ' ';
            }
            $time                = $startTime;
            $dateFormat = $this->_scopeConfig->getValue(self::XML_PATH_DATE_FORMAT);

            if (!empty($session->getDate())) {
                $date = substr($session->getDate(), 0, 10);
                $date     = trim(date($dateFormat, strtotime($date)));
            }
            $additionalOptions['session'][] = [
                'label' => 'Time',
                'value' => $time
            ];
            $additionalOptions['date'][] = [
                'label' => 'Date',
                'value' => $date
            ];
        }

        if (!empty($ticketParams['ticket_info'])) {
            $additionalOptions[] = [
                'label' => 'info',
                'value' => $ticketParams['ticket_info']
            ];
        }
        $check = class_exists('Magento\Framework\Serialize\Serializer\Json');
        if ($check) {
            return json_encode($additionalOptions);
        } else {
            return $this->serialize->serialize($additionalOptions);
        }
    }

}
