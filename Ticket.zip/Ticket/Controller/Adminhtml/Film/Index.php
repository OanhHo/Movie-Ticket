<?php
namespace Movie\Ticket\Controller\Adminhtml\Film;

use Movie\Ticket\Controller\Adminhtml\Film as FilmController;

/**
 * Class Index
 * @package Movie\Ticket\Controller\Adminhtml\Film
 */
class Index extends FilmController
{
    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        $this->_setPageData();

        return $this->getResultPage();
    }
}
