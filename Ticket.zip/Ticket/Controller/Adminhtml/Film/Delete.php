<?php

namespace Movie\Ticket\Controller\Adminhtml\Film;

use Movie\Ticket\Model\FilmFactory;
use Movie\Ticket\Model\ResourceModel\Film\CollectionFactory as FilmCollectionFactory;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\Controller\ResultFactory;
use Movie\Ticket\Controller\Adminhtml\Film as FilmController;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Ui\Component\MassAction\Filter;

/**
 * Class Delete
 * @package Movie\Ticket\Controller\Adminhtml\Film
 */
class Delete extends FilmController
{
    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $_productFactory;

    /**
     * Delete constructor.
     * @param Context $context
     * @param FilmFactory $filmFactory
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param FileFactory $fileFactory
     * @param Filter $filter
     * @param FilmCollectionFactory $collectionFactory
     * @param \Magento\Catalog\Model\ProductFactory $_productFactory
     */
    public function __construct(
        Context $context,
        FilmFactory $filmFactory,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        FileFactory $fileFactory,
        Filter $filter,
        FilmCollectionFactory $collectionFactory,
        \Magento\Catalog\Model\ProductFactory $_productFactory
    ) {
        $this->_productFactory = $_productFactory;
        parent::__construct($context, $filmFactory, $coreRegistry, $resultPageFactory, $fileFactory, $filter,
            $collectionFactory);
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->_collectionFactory->create());
        $delete = 0;
        foreach ($collection as $item) {
            $product = $this->_productFactory->create()->load($item->getProductId());
            if (!empty($product->getId()))
            {
                $product->delete();
            }
            /** @var \Magenest\Ticket\Model\Event $item */
            $item->delete();
            $delete++;
        }
        $this->messageManager->addSuccess(__('A total of %1 record(s) have been deleted.', $delete));
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

        return $resultRedirect->setPath('*/*/');
    }
}
