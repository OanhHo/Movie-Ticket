<?php
namespace Movie\Ticket\Controller\Adminhtml\Ticket;

use Movie\Ticket\Controller\Adminhtml\Ticket as TicketController;

/**
 * Class Index
 * @package Movie\Ticket\Controller\Adminhtml\Ticket
 */
class Index extends TicketController
{
    /**
     * execute the action
     *
     * @return \Magento\Backend\Model\View\Result\Page|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $this->_setPageData();

        return $this->getResultPage();
    }
}
