<?php

namespace Movie\Ticket\Controller\Adminhtml;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Backend\Model\View\Result\Page;
use Movie\Ticket\Model\ResourceModel\Cinema\CollectionFactory as CinemaCollectionFactory;
use Movie\Ticket\Model\CinemaFactory;


/**
 * Class Cinema
 * @package Movie\Ticket\Controller\Adminhtml
 */
abstract class Cinema extends Action
{
    /**
     * Core registry
     *
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * Page result factory
     *
     * @var PageFactory
     */
    protected $_resultPageFactory;

    /**
     * Page factory
     *
     * @var Page
     */
    protected $_resultPage;

    /**
     * Mass Action Filter
     *
     * @var Filter
     */
    protected $_filter;

    /**
     * @var FileFactory
     */
    protected $_fileFactory;
    /**
     * @var CinemaFactory
     */
    protected $_cinemaFactory;
    /**
     * @var CinemaCollectionFactory
     */
    protected $_collectionFactory;

    /**
     * Cinema constructor.
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param FileFactory $fileFactory
     * @param CinemaFactory $cinemaFactory
     * @param CinemaCollectionFactory $collectionFactory
     * @param Filter $filter
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        FileFactory $fileFactory,
        CinemaFactory $cinemaFactory,
        CinemaCollectionFactory $collectionFactory,
        Filter $filter
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_fileFactory = $fileFactory;
        $this->_filter = $filter;
        $this->_cinemaFactory=$cinemaFactory;
        $this->_collectionFactory=$collectionFactory;
        parent::__construct($context);
    }

    /**
     * @return Page|\Magento\Framework\View\Result\Page
     */
    public function getResultPage()
    {
        if (is_null($this->_resultPage)) {
            $this->_resultPage = $this->_resultPageFactory->create();
        }

        return $this->_resultPage;
    }

    /**
     * set page data
     *
     * @return $this
     */
    protected function _setPageData()
    {
        $resultPage = $this->getResultPage();
        $resultPage->setActiveMenu('Movie_Ticket::cinema');
        $resultPage->getConfig()->getTitle()->prepend((__('Manage Cinemas')));

        return $this;
    }

    /**
     * Check ACL
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Movie_Ticket::cinema');
    }
}
