<?php
namespace Movie\Ticket\Controller\Adminhtml\Template;
/**
 * Class NewDelete
 * @package Movie\Ticket\Controller\Adminhtml\Template
 */
class NewDelete extends \Magento\Backend\App\Action
{

    const ADMIN_RESOURCE = 'Index';

    protected $_resultPageFactory;
    protected $_templateFactory;
    protected $_request;
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Movie\Ticket\Model\TemplateFactory $templateFactory
    )
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_templateFactory = $templateFactory;
        $this->_request=$context->getRequest();
        parent::__construct($context);
    }

    public function execute()
    {
        $id = $this->_request->getParam('template_id');

        $contact = $this->_templateFactory->create()->load($id);

        if(!$contact)
        {
            $this->messageManager->addError(__('Unable to process. please, try again.'));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/', array('_current' => true));
        }

        try{
            $contact->delete();
            $this->messageManager->addSuccess(__('Your template has been deleted !'));
        }
        catch(\Exception $e)
        {
            $this->messageManager->addError(__('Error while trying to delete template'));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/index', array('_current' => true));
        }

        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/index', array('_current' => true));
    }
}