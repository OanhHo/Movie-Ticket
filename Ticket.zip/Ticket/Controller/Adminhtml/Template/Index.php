<?php

namespace Movie\Ticket\Controller\Adminhtml\Template;

use Movie\Ticket\Controller\Adminhtml\Template as TemplateController;

/**
 * Class Index
 * @package Movie\Ticket\Controller\Adminhtml\Template
 */
class Index extends TemplateController
{
    /**
     * @return \Magento\Backend\Model\View\Result\Page|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $this->_setPageData();

        return $this->getResultPage();
    }
}
