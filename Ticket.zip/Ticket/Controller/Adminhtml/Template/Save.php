<?php

namespace Movie\Ticket\Controller\Adminhtml\Template;

use \Magento\Backend\App\Action\Context;
use Magento\Framework\App\Response\Http\FileFactory;
use Movie\Ticket\Helper\Pdf as PdfHelper;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Serialize\Serializer\Serialize;

/**
 * Class Save
 * @package Movie\Ticket\Controller\Adminhtml\Template
 */
class Save extends \Magento\Backend\App\Action
{
    /**
     * @var FileFactory
     */
    protected $fileFactory;

    /**
     * @var PdfHelper
     */
    protected $_pdfHelper;

    /**
     * @var Serialize
     */
    protected $serialize;

    /**
     * Save constructor.
     *
     * @param Context $context
     * @param FileFactory $fileFactory
     * @param PdfHelper $pdfHelper
     * @param Serialize $serialize
     */
    public function __construct(
        Context $context,
        FileFactory $fileFactory,
        PdfHelper $pdfHelper,
        Serialize $serialize

    ) {
        $this->fileFactory = $fileFactory;
        $this->_pdfHelper  = $pdfHelper;
        $this->serialize   = $serialize;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $post           = $this->getRequest()->getPostValue();
        $resultRedirect = $this->resultRedirectFactory->create();
        if (!empty($post['pdf_coordinates'])) {
            foreach ($post['pdf_coordinates'] as $key => $pdf_coordinate) {
                if (isset($pdf_coordinate['is_delete'])) {
                    unset($post['pdf_coordinates'][$key]);
                }
                if (isset($pdf_coordinate['x'])) {
                    if ($pdf_coordinate['x'] > $post['pdf_page_width']) {
                        $this->messageManager->addErrorMessage(__('Coordinate X cannot exceed the Page Width.'));

                        $post['pdf_coordinates'][$key]['x'] = 0;
                    }
                }
                if (isset($pdf_coordinate['y'])) {
                    if ($pdf_coordinate['y'] > $post['pdf_page_height']) {
                        $this->messageManager->addErrorMessage(__('Coordinate Y cannot exceed the Page Height.'));

                        $post['pdf_coordinates'][$key]['y'] = 0;
                    }
                }
            }
        } else {
            $post['pdf_coordinates'] = [];
        }

        $post['pdf_coordinates'] = array_values($post['pdf_coordinates']);

        if (!$post) {
            return $resultRedirect->setPath('*/*/');
        }
        try {
            $array = [
                'title'           => isset($post['title']) ? $post['title'] : '',
                'enable'          => isset($post['enable']) ? $post['enable'] : 0,
                'pdf_page_width'  => $post['pdf_page_width'],
                'pdf_page_height' => $post['pdf_page_height'],
                'pdf_background'  => isset($post['pdf_background']) ? $this->serialize->serialize($post['pdf_background']) : $this->serialize->serialize([]),
                'pdf_coordinates' => isset($post['pdf_coordinates']) ? $this->serialize->serialize($post['pdf_coordinates']) : $this->serialize->serialize([]),
            ];

            $model = $this->_objectManager->create('Movie\Ticket\Model\Template');

            if (isset($post['template_id'])) {
                $model->load($post['template_id']);
            }
            $model->addData($array);
            $model->save();
            $this->messageManager->addSuccessMessage(__('The template has been saved.'));
            $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData(false);

            return $resultRedirect->setPath('*/template/edit', ['template_id' => $model->getTemplateId()]);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e, __('Something went wrong while saving the rule.'));
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($post);

            return $resultRedirect->setPath('*/*/edit',
                ['template_id' => $this->getRequest()->getParam('template_id')]);
        }

        return $resultRedirect->setPath('*/template/edit', ['template_id' => $model->getTemplateId()]);
    }
}
