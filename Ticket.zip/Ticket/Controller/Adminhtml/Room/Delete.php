<?php

namespace Movie\Ticket\Controller\Adminhtml\Room;

use Magento\Framework\Controller\ResultFactory;
use Movie\Ticket\Controller\Adminhtml\Room as RoomController;

/**
 * Class Delete
 * @package Movie\Ticket\Controller\Adminhtml\Room
 */
class Delete extends RoomController
{
    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->_collectionFactory->create());

        $delete = 0;
        foreach ($collection as $item) {

            $modelDate = $this->_objectManager->create('Movie\Ticket\Model\Date');
            $dateCollection=$modelDate->getCollection()
                ->addFieldToFilter('room_id',$item->getRoomId());
            foreach ($dateCollection as $date){
                $data=$modelDate->load($date->getDateId());
                $data->delete();
            }
            $item->delete();
            $delete++;
        }
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $delete));
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

        return $resultRedirect->setPath('*/*/');
    }
}
