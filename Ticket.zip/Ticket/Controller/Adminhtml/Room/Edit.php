<?php

namespace Movie\Ticket\Controller\Adminhtml\Room;

use Magento\Framework\Controller\ResultFactory;

/**
 * Class Edit
 * @package Movie\Ticket\Controller\Adminhtml\Template
 */
class Edit extends \Magento\Backend\App\Action
{
    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $id = $this->getRequest()->getParam('room_id');
        if ($id) {
            $model = $this->_objectManager->create('Movie\Ticket\Model\Room')->load($id);
            $title = "Edit Room: " . $model->getTitle();
        } else {
            $title = 'New Room';
        }
        $resultPage->getConfig()->getTitle()->prepend($title);

        return $resultPage;
    }
}
