<?php
namespace Movie\Ticket\Controller\Adminhtml\Room;

use Movie\Ticket\Controller\Adminhtml\Room as RoomController;

/**
 * Class Index
 * @package Movie\Ticket\Controller\Adminhtml\Room
 */
class Index extends RoomController
{
    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        $this->_setPageData();

        return $this->getResultPage();
    }
}
