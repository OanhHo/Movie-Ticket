<?php

namespace Movie\Ticket\Controller\Adminhtml\Room;

use Magento\Backend\App\Action;
use \Magento\Backend\App\Action\Context;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Framework\Serialize\Serializer\Serialize;
/**
 * Class Save
 * @package Movie\Ticket\Controller\Adminhtml\Room
 */
class Save extends \Magento\Backend\App\Action
{
    /**
     * @var FileFactory
     */
    protected $fileFactory;
    /**
     * @var Serialize
     */
    protected $serialize;
    /**
     * @var \Movie\Ticket\Model\DateFactory
     */
    protected $_dateFactory;
    /**
     * @var ResolverInterface
     */
    protected $resolver;

    /**
     * Save constructor.
     * @param Context $context
     * @param FileFactory $fileFactory
     * @param Serialize $serialize
     * @param \Movie\Ticket\Model\DateFactory $dateFactory
     * @param ResolverInterface $resolverInterface
     */
    public function __construct(Action\Context $context,
                                FileFactory $fileFactory,
                                Serialize $serialize,
                                \Movie\Ticket\Model\DateFactory $dateFactory,
                                ResolverInterface $resolverInterface)
    {
        $this->fileFactory = $fileFactory;
        $this->serialize   = $serialize;
        $this->_dateFactory=$dateFactory;
        $this->resolver=$resolverInterface;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $post           = $this->getRequest()->getPostValue();
        $resultRedirect = $this->resultRedirectFactory->create();
        if (!empty($post['data']['room']['movie_room_sit']['detail'])) {
            foreach ($post['data']['room']['movie_room_sit']['detail'] as $key => $detail) {
                if (isset($detail['is_delete'])) {
                    unset($post['data']['room']['movie_room_sit']['detail'][$key]);
                }
            }
        } else {
            $post['data']['room']['movie_room_sit']['detail'] = [];
        }

        $post['data']['room']['movie_room_sit']['detail'] = array_values($post['data']['room']['movie_room_sit']['detail']);

        if (!$post) {
            return $resultRedirect->setPath('*/*/');
        }


        try {
            $arrayRoom = [
                'title'           => isset($post['title']) ? $post['title'] : '',
                'cinema_id'           => isset($post['cinema_id']) ? $post['cinema_id'] : '',
                'enabled'          => isset($post['enabled']) ? $post['enabled'] : 0,
                'detail' => isset($post['data']['room']['movie_room_sit']['detail']) ?
                    $this->serialize->serialize($post['data']['room']['movie_room_sit']['detail']) : $this->serialize->serialize([]),
            ];

            $model = $this->_objectManager->create('Movie\Ticket\Model\Room');

            if (isset($post['room_id'])) {
                $model->load($post['room_id']);
            }
            $model->addData($arrayRoom);
            $model->save();
            if (!empty($post['data']['room']['room_date_session']['room_date'])) {
                foreach ($post['data']['room']['room_date_session']['room_date'] as $key => $date) {
                    if (isset($date['is_delete'])) {
                        unset($post['data']['room']['room_date_session']['room_date'][$key]);
                    }
                }
                $this->saveDate($post['data']['room']['room_date_session']['room_date'],$model->getRoomId());

            }
            else{
                $post['data']['room']['movie_date_session']['room_date']=[];
            }
            $this->messageManager->addSuccessMessage(__('The room has been saved.'));
            $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData(false);

            return $resultRedirect->setPath('*/room/edit', ['room_id' => $model->getRoomId()]);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e, __('Something went wrong while saving the rule.'));
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($post);

            return $resultRedirect->setPath('*/*/edit',
                ['room_id' => $this->getRequest()->getParam('room_id')]);
        }

        return $resultRedirect->setPath('*/room/edit', ['room_id' => $model->getRoomId()]);
    }
    public function saveDate($dateData, $idRoom)
    {
        foreach ($dateData as $dateInfo) {
            if (!isset($once)) {
                $once = true;
            }
            if (array_key_exists('delete_day', $dateInfo)) {
                if (isset($dateInfo['id_date'])) {
                    $modelDate = $this->_dateFactory->create()->load($dateInfo['id_date']);
                    $modelDate->delete();
                }
                continue;
            } else {
                if ($once) {
                    $deletedDates = $this->getDeletedItem('date', $dateData, $idRoom);

                    foreach ($deletedDates as $dates) {
                        $this->_dateFactory->create()->load($dates)->delete();
                    }
                    $once = false;
                }
            }
            $modelDate = $this->_dateFactory->create();
            if (isset($dateInfo['id_date'])) {
                $modelDate->load($dateInfo['id_date']);
            }
            $data['room_id'] = $idRoom;

            $locdatestart = date('m/d/Y', (new \IntlDateFormatter(
                $this->resolver->getLocale(), \IntlDateFormatter::SHORT, \IntlDateFormatter::NONE))->parse($dateInfo['time_date_start']));
            $locdateend = date('m/d/Y', (new \IntlDateFormatter(
                $this->resolver->getLocale(), \IntlDateFormatter::SHORT, \IntlDateFormatter::NONE))->parse($dateInfo['time_date_end']));

            $dateInfo['time_date_start'] = $locdatestart;
            $dateInfo['time_date_end'] = $locdateend;

            $data['date_is_enabled'] = $dateInfo['date_enabled'];
            $data['date_start'] = isset($dateInfo['time_date_start']) ? $dateInfo['time_date_start'] : '';
            $data['date_end'] = isset($dateInfo['time_date_end']) ? $dateInfo['time_date_end'] : '';
            if (isset($dateInfo['row_session'])) {
                foreach ($dateInfo['row_session'] as $index => $session) {
                    if (isset($session['is_delete'])) {
                        unset($dateInfo['row_session'][$index]);
                    }
                }
                $data['session'] = isset($dateInfo['row_session']) ? $this->serialize->serialize($dateInfo['row_session']) : $this->serialize->serialize([]);
                if (isset($dateInfo['time_date_start']) && !empty($dateInfo['time_date_end'])) {
                    $start = $dateInfo['time_date_start'];
                    $end = $dateInfo['time_date_end'];
                    $counter=0;
                    if ($start == $end) {
                        $rowSession=$dateInfo['row_session'];
                        $size=count($rowSession);
                        for ($i = 0; $i < $size; $i++) {
                            $dateSession['date_session'][$counter] = [
                                'date_id'=>$dateInfo['id_date'],
                                'date' => $start,
                                'start_time' => $rowSession[$i]['start_time'],
                                'session_is_enabled' => $rowSession[$i]['session_enabled']

                            ];
//                            $this->saveSession($dateSession['date_session'][$counter],$dateInfo['id_date']);
                            $counter ++;
                        }
                    } else {
                        while ($start <= $end) {
                            $rowSession=$dateInfo['row_session'];
                            $size=count($rowSession);
                            for ($i = 0; $i < $size; $i++) {
                                $dateSession['date_session'][$counter] = [
                                    'date_id'=>$dateInfo['id_date'],
                                    'date' => $start,
                                    'start_time' => $rowSession[$i]['start_time'],
                                    'session_is_enabled' => $rowSession[$i]['session_enabled']

                                ];
//                                $this->saveSession($dateSession['date_session'][$counter],$dateInfo['id_date']);
                                $counter ++;
                            }
                            $start = date_create($start);
                            date_modify($start, "+01 days");
                            $start = date_format($start, "m/d/Y");
                        }
                    }
                    $data['date_session']=$this->serialize->serialize($dateSession['date_session']);

                } else {
                    $post['data']['room']['movie_date_session']['room_date'] = [];
                }

                $modelDate->addData($data)->save();
            }
        }
    }

    public function getDeletedItem($type, $data, $roomId, $dateId = null)
    {
        switch ($type) {
            case 'date':
            {
                $currentRecord = [];
                $oldRecord     = [];
                foreach ($data as $date) {
                    if (empty($date['id_date'])) {
                        continue;
                    }
                    array_push($currentRecord, intval($date['id_date']));
                }
                $oldScheduleCollections = $this->_dateFactory->create()->getCollection()
                    ->addFieldToFilter('room_id', $roomId);
                foreach ($oldScheduleCollections as $dates) {
                    array_push($oldRecord, intval($dates->getDateId()));
                }

                return array_diff($oldRecord, $currentRecord);
            }
            default:
            {
                return null;
            }

        }
    }

}
