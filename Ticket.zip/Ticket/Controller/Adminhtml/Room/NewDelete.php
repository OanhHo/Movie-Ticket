<?php
namespace Movie\Ticket\Controller\Adminhtml\Room;
/**
 * Class NewDelete
 * @package Movie\Ticket\Controller\Adminhtml\Room
 */
class NewDelete extends \Magento\Backend\App\Action
{

    const ADMIN_RESOURCE = 'Index';
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;
    /**
     * @var \Movie\Ticket\Model\RoomFactory
     */
    protected $_roomFactory;
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;
    /**
     * @var \Movie\Ticket\Model\DateFactory
     */
    protected $_dateFatory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Movie\Ticket\Model\RoomFactory $roomFactory,
        \Movie\Ticket\Model\DateFactory $dateFactory
    )
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_roomFactory = $roomFactory;
        $this->_request=$context->getRequest();
        $this->_dateFatory=$dateFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $id = $this->_request->getParam('room_id');

        $contact = $this->_roomFactory->create()->load($id);

        if(!$contact)
        {
            $this->messageManager->addError(__('Unable to process. please, try again.'));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/', array('_current' => true));
        }

        try{
            $modelDate=$this->_dateFatory->create()->getCollection()
                ->addFieldToFilter('room_id',$id);
            foreach ($modelDate as $date){
                $s=1;
                $data=$this->_dateFatory->create()->load($date->getDateId());
                $data->delete();
            }
            $contact->delete();
            $this->messageManager->addSuccess(__('Your room has been deleted !'));
        }
        catch(\Exception $e)
        {
            $this->messageManager->addError(__('Error while trying to delete room'));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/index', array('_current' => true));
        }

        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/index', array('_current' => true));
    }
}