<?php
namespace Movie\Ticket\Controller\Adminhtml\Cinema;

/**
 * Class NewDelete
 * @package Movie\Ticket\Controller\Adminhtml\Cinema
 */
class NewDelete extends \Magento\Backend\App\Action
{
    const ADMIN_RESOURCE = 'Index';
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;
    /**
     * @var \Movie\Ticket\Model\CinemaFactory
     */
    protected $_cinemaFactory;
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * NewDelete constructor.
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Movie\Ticket\Model\CinemaFactory $cinemaFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Movie\Ticket\Model\CinemaFactory $cinemaFactory
    )
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_cinemaFactory = $cinemaFactory;
        $this->_request=$context->getRequest();
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $id = $this->_request->getParam('cinema_id');

        $contact = $this->_cinemaFactory->create()->load($id);

        if(!$contact)
        {
            $this->messageManager->addError(__('Unable to process. please, try again.'));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/', array('_current' => true));
        }

        try{
            $contact->delete();
            $this->messageManager->addSuccess(__('Your cinema has been deleted !'));
        }
        catch(\Exception $e)
        {
            $this->messageManager->addError(__('Error while trying to delete cinema'));
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/index', array('_current' => true));
        }

        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/index', array('_current' => true));
    }
}