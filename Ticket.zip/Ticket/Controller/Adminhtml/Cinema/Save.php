<?php

namespace Movie\Ticket\Controller\Adminhtml\Cinema;

use Magento\Backend\App\Action;
use \Magento\Backend\App\Action\Context;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Serialize\Serializer\Serialize;

/**
 * Class Save
 * @package Movie\Ticket\Controller\Adminhtml\Cinema
 */
class Save extends \Magento\Backend\App\Action
{
    /**
     * @var FileFactory
     */
    protected $fileFactory;
    /**
     * @var Serialize
     */
    protected $serialize;

    /**
     * Save constructor.
     * @param Context $context
     * @param FileFactory $fileFactory
     * @param Serialize $serialize
     */
    public function __construct(Action\Context $context,
                                FileFactory $fileFactory,
                              Serialize $serialize)
    {
        $this->fileFactory = $fileFactory;
        $this->serialize   = $serialize;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $post           = $this->getRequest()->getPostValue();
        $resultRedirect = $this->resultRedirectFactory->create();
        if (!$post) {
            return $resultRedirect->setPath('*/*/');
        }
        try {
            $array = [
                'name'           => isset($post['name']) ? $post['name'] : '',
                'address'           => isset($post['address']) ? $post['address'] : '',
                'enabled'          => isset($post['enabled']) ? $post['enabled'] : 0,
            ];

            $model = $this->_objectManager->create('Movie\Ticket\Model\Cinema');

            if (isset($post['cinema_id'])) {
                $model->load($post['cinema_id']);
            }
            $model->addData($array);
            $model->save();
            $this->messageManager->addSuccessMessage(__('The cinema has been saved.'));
            $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData(false);

            return $resultRedirect->setPath('*/cinema/edit', ['cinema_id' => $model->getCinemaId()]);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e, __('Something went wrong while saving the rule.'));
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($post);

            return $resultRedirect->setPath('*/*/edit',
                ['room_id' => $this->getRequest()->getParam('cinema_id')]);
        }

        return $resultRedirect->setPath('*/cinema/edit', ['cinema_id' => $model->getCinemaId()]);
    }
}
