<?php
namespace Movie\Ticket\Controller\Adminhtml\Cinema;

use Movie\Ticket\Controller\Adminhtml\Cinema as CinemaController;

/**
 * Class Index
 * @package Movie\Ticket\Controller\Adminhtml\Cinema
 */
class Index extends CinemaController
{
    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        $this->_setPageData();

        return $this->getResultPage();
    }
}
