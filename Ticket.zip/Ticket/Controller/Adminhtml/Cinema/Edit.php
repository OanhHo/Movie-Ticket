<?php

namespace Movie\Ticket\Controller\Adminhtml\Cinema;

use Magento\Framework\Controller\ResultFactory;

/**
 * Class Edit
 * @package Movie\Ticket\Controller\Adminhtml\Cinema
 */
class Edit extends \Magento\Backend\App\Action
{
    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $id = $this->getRequest()->getParam('cinema_id');
        if ($id) {
            $model = $this->_objectManager->create('Movie\Ticket\Model\Cinema')->load($id);
            $title = "Edit Cinema: " . $model->getTitle();
        } else {
            $title = 'New Cinema';
        }
        $resultPage->getConfig()->getTitle()->prepend($title);

        return $resultPage;
    }
}
