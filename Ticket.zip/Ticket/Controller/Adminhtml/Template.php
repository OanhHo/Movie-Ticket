<?php

namespace Movie\Ticket\Controller\Adminhtml;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Backend\Model\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;
use Magento\Ui\Component\MassAction\Filter;
use Movie\Ticket\Model\ResourceModel\Template\CollectionFactory as TemplateCollectionFactory;
use Movie\Ticket\Model\TemplateFactory;

/**
 * Class Template
 * @package Movie\Ticket\Controller\Adminhtml
 */
abstract class Template extends Action
{

    /**
     * Core registry
     *
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * Page result factory
     *
     * @var PageFactory
     */
    protected $_resultPageFactory;

    /**
     * Page factory
     *
     * @var Page
     */
    protected $_resultPage;

    /**
     * Mass Action Filter
     *
     * @var Filter
     */
    protected $_filter;
    /**
     * @var TemplateCollectionFactory
     */
    protected $_collectionFactory;
    protected $_templateFactory;


    /**
     * Template constructor.
     * @param Registry $coreRegistry
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param TemplateCollectionFactory $collectionFactory
     * @param TemplateFactory $templateFactory
     * @param Filter $filter
     */
    public function __construct(
        Registry $coreRegistry,
        Context $context,
        PageFactory $resultPageFactory,
        TemplateCollectionFactory $collectionFactory,
        TemplateFactory $templateFactory,
        Filter $filter
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_filter = $filter;
        $this->_collectionFactory=$collectionFactory;
        $this->_templateFactory=$templateFactory;
        parent::__construct($context);
    }

    /**
     * @return Page|\Magento\Framework\View\Result\Page
     */
    public function getResultPage()
    {
        if (is_null($this->_resultPage)) {
            $this->_resultPage = $this->_resultPageFactory->create();
        }

        return $this->_resultPage;
    }

    /**
     * set page data
     *
     * @return $this
     */
    protected function _setPageData()
    {
        $resultPage = $this->getResultPage();
        $resultPage->setActiveMenu('Movie_Ticket::tickets');
        $resultPage->getConfig()->getTitle()->prepend((__('PDF Template')));

        return $this;
    }
}
