<?php

namespace Movie\Ticket\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Magento\Setup\Exception;
use Magento\Store\Model\StoreManagerInterface;
use Movie\Ticket\Model\FilmFactory;
use Movie\Ticket\Model\DateFactory;
use Movie\Ticket\Model\DateSessionFactory;
use Movie\Ticket\Model\TemplateFactory;
use Movie\Ticket\Model\CinemaFactory;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\View\Element\Template;
use Magento\Framework\App\ProductMetadata;
use Magento\Framework\Serialize\Serializer\Serialize;

/**
 * Class Pdf
 * @package Magenest\Ticket\Helper
 */
class Pdf extends AbstractHelper
{
    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var Filesystem
     */
    protected $filesystem;

    /**
     * @var EventFactory
     */
    protected $_eventFactory;

    /**
     * @var File
     */
    protected $fileFramework;

    /**
     * @var Template
     */
    protected $template;

    /**
     * @var EventSessionFactory
     */
    protected $session;

    /**
     * @var EventLocationFactory
     */
    protected $location;

    /**
     * @var EventDateFactory
     */
    protected $date;

    /**
     * @var Information
     */
    protected $information;

    /**
     * @var TemplateFactory
     */
    protected $templateFactory;

    /**
     * @var EventoptionTypeFactory
     */
    protected $_eventoptionTypeFactory;

    /**
     * @var ProductMetadata
     */
    protected $productMetadata;

    /**
     * @var Serialize
     */
    protected $serialize;
    protected $_filmFactory;
    protected $_dateFactory;
    protected $_sessionFactory;
    protected $_templateFactory;
    /**
     * @var CinemaFactory
     */
    protected $_cinemaFactory;

    /**
     * Pdf constructor.
     * @param Context $context
     * @param StoreManagerInterface $storeManager
     * @param Filesystem $filesystem
     * @param File $fileFramework
     * @param Template $template
     * @param Information $information
     * @param Serialize $serialize
     * @param ProductMetadata $productMetadata
     * @param FilmFactory $filmFactory
     * @param DateFactory $dateFactory
     * @param DateSessionFactory $dateSessionFactory
     * @param CinemaFactory $cinemaFactory
     * @param TemplateFactory $templateFactory
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        Filesystem $filesystem,
        File $fileFramework,
        Template $template,
        Information $information,
        Serialize $serialize,
        ProductMetadata $productMetadata,
        FilmFactory $filmFactory,
        DateFactory $dateFactory,
        DateSessionFactory  $dateSessionFactory,
        CinemaFactory $cinemaFactory,
        TemplateFactory $templateFactory
    ) {
        parent::__construct($context);
        $this->_storeManager           = $storeManager;
        $this->filesystem              = $filesystem;
        $this->fileFramework           = $fileFramework;
        $this->template                = $template;
        $this->information             = $information;
        $this->serialize               = $serialize;
        $this->productMetadata         = $productMetadata;
        $this->_filmFactory             =$filmFactory;
        $this->_dateFactory             =$dateFactory;
        $this->_sessionFactory          =$dateSessionFactory;
        $this->_cinemaFactory         =$cinemaFactory;
        $this->_templateFactory         =$templateFactory;
    }

    public function getPdf($ticket)
    {
        $pdf = new \Zend_Pdf();
        try {
            $filmModel = $ticket->getFilm();
            if ($filmModel->getUseCustomTemplate() == 1) {
                $film = $filmModel;
            } else {
                $film = $this->_templateFactory->create()->load($filmModel->getTemplateId());
            }
            $fontRegular    = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA);
            $fontBold       = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA_BOLD);
            $fontBoldItalic = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA_BOLD_ITALIC);
            $fontItalic     = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA_ITALIC);

            $width  = $film->getPdfPageWidth();
            $height = $film->getPdfPageHeight();

            if ($width > 0 && $height > 0) {
                $size = $width . ':' . $height;
            } else {
                $size = '600:400';
            }

            $page = $pdf->newPage($size);
            if (!empty($film->getPdfBackground())) {
                $backgroundLink = $this->serialize->unserialize($film->getPdfBackground());
                if (isset($backgroundLink) && !empty($backgroundLink)) {
                    if (isset($backgroundLink['0']['file'])) {
                        $background = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA)
                            ->getAbsolutePath('ticket/template/' . $backgroundLink['0']['file']);
                    }
                    if (isset($background) && is_file($background)) {
                        $image = \Zend_Pdf_Image::imageWithPath($background);
                        $page->drawImage($image, 0, 0, $width, $height);
                    }
                }
            }

            $code = $ticket->getCode();
            $page->setFont($fontRegular, 15);
            $coordinates  = $film->getPdfCoordinates();
            $tableRowsArr = [];

            if (isset($coordinates)) {
                $tableRowsArr = $this->serialize->unserialize($coordinates);
            }

            foreach ($tableRowsArr as $param) {
                /**
                 * Insert QR Code to PDF File
                 */
                if (!empty($param['info']) && $param['info'] == 'qr_code'
                    && !empty($param['x']) && !empty($param['y']) && !empty($param['size'])) {
                    $fileName   = $this->getQrCode($code);
                    $pathQrcode = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA)
                        ->getAbsolutePath($fileName);
                    $image      = \Zend_Pdf_Image::imageWithPath($pathQrcode);
                    $page->drawImage(
                        $image,
                        $param['x'],
                        $param['y'],
                        $param['x'] + $param['size'],
                        $param['y'] + $param['size']
                    );

                    unlink($pathQrcode);
                    continue;
                }

                /**
                 * Insert Barcode to PDF File
                 */
                if (!empty($param['info']) && $param['info'] == 'bar_code') {
                    $barcodeOptions  = ['text' => $code, 'drawText' => false];
                    $rendererOptions = [];
                    $magentoVer      = $this->productMetadata->getVersion();
                    if (version_compare($magentoVer, '2.3', '>=')) {
                        $imageResource = $this->generateBarcode($code);
                    } else {
                        $imageResource = \Zend_Barcode::draw('code128', 'image', $barcodeOptions, $rendererOptions);
                    }
                    $barcode = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA)
                        ->getAbsolutePath('barcode.jpg');
                    imagejpeg($imageResource, $barcode, 100);
                    imagedestroy($imageResource);
                    $image = \Zend_Pdf_Image::imageWithPath($barcode);
                    $page->drawImage(
                        $image,
                        $param['x'],
                        $param['y'],
                        $param['x'] + $param['size'] * 2,
                        $param['y'] + $param['size']
                    );
                    unlink($barcode);
                    continue;
                }

                /**
                 * Insert film image
                 */
                if (isset($param['info'])) {
                    if ($param['info'] == "film_photo") {
                        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                        $product       = $objectManager->get('Magento\Catalog\Model\Product')->load($filmModel->getProductId());
                        if (!$product->getImage()) {
                            continue;
                        }
                        $imageUrl = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA)
                            ->getAbsolutePath('catalog/product' . $product->getImage());

                        $background = $imageUrl;
                        $image      = \Zend_Pdf_Image::imageWithPath($background);
                        $page->drawImage(
                            $image,
                            $param['x'],
                            $param['y'],
                            $param['x'] + $param['size'],
                            $param['y'] + $param['size']
                        );
                    }
                }

                /**
                 * Insert diffenceinformation
                 */
                if (!empty($param['info'])
                    && !empty($param['x'])
                    && !empty($param['y'])
                    && !empty($param['size'])
                    && !empty($param['color'])) {
                    $text   = $this->replaceByTicket($ticket, $param['info']);
                    $format = $fontRegular;
                    if (isset($param['format'])) {
                        switch ($param['format']) {
                            case 'bold':
                                $format = $fontBold;
                                break;
                            case 'italic':
                                $format = $fontItalic;
                                break;
                            case 'bold_italic':
                                $format = $fontBoldItalic;
                                break;
                            default:
                                $format = $fontRegular;
                        }
                    }
                    $page->setFont($format, $param['size']);
                    $color = new \Zend_Pdf_Color_Html($param['color']);
                    $page->setFillColor($color);
                    if (isset($param['title']) && !empty($param['title'])) {
                        $textEnd = $param['title'] . ': ' . $text;
                    } else {
                        $textEnd = $text;
                    }
                    $convertTextEnd=$this->convertStr($textEnd);
                    $textWidth = $this->getTextWidth($convertTextEnd, $format, $param['size']);
                    if (isset($param['align'])) {
                        switch ($param['align']) {
                            case 'center':
                                $textChunk = wordwrap($convertTextEnd, 30, "\n");
                                $line      = $param['y'];
                                foreach (explode("\n", $textChunk) as $textLine) {
                                    if ($textLine !== '') {
                                        $textWidth = $this->getTextWidth($textLine, $format, $param['size']);
                                        $page->drawText(
                                            strip_tags(ltrim($textLine)),
                                            ($param['x'] / 2) - ($textWidth / 2),
                                            $line,
                                            'UTF-8'
                                        );
                                        $line -= $param['size'] + 3;
                                    }
                                }
                                break;
                            case 'right':
                                $page->drawText(
                                    $convertTextEnd,
                                    $param['x'] - $textWidth - $param['size'],
                                    $param['y']
                                );
                                break;

                            default:
                                $page->drawText(
                                    $convertTextEnd,
                                    $param['x'],
                                    $param['y'],
                                    'UTF-8'
                                );
                        }
                    } else {
                        $page->drawText(
                            $convertTextEnd,
                            $param['x'],
                            $param['y'],
                            'UTF-8'
                        );
                    }
                }
            }
            $pdf->pages[] = $page;
        } catch (\Exception $exception) {
            \Magento\Framework\App\ObjectManager::getInstance()->get('Psr\Log\LoggerInterface')->critical($exception);
        }

        return $pdf;
    }

    /**
     * generate Barcode image from string, replace Zend_barcode in Magento 2.3
     *
     * @param $code
     *
     * @return resource
     */
    public function generateBarcode($code)
    {
        $code_string = "";
        $chksum      = 104;
        /*code128 array*/
        $code_array  = [" "       => "212222", "!" => "222122", "\"" => "222221", "#" => "121223", "$" => "121322",
            "%"       => "131222", "&" => "122213", "'" => "122312", "(" => "132212", ")" => "221213",
            "*"       => "221312", "+" => "231212", "," => "112232", "-" => "122132", "." => "122231",
            "/"       => "113222", "0" => "123122", "1" => "123221", "2" => "223211", "3" => "221132",
            "4"       => "221231", "5" => "213212", "6" => "223112", "7" => "312131", "8" => "311222",
            "9"       => "321122", ":" => "321221", ";" => "312212", "<" => "322112", "=" => "322211",
            ">"       => "212123", "?" => "212321", "@" => "232121", "A" => "111323", "B" => "131123",
            "C"       => "131321", "D" => "112313", "E" => "132113", "F" => "132311", "G" => "211313",
            "H"       => "231113", "I" => "231311", "J" => "112133", "K" => "112331", "L" => "132131",
            "M"       => "113123", "N" => "113321", "O" => "133121", "P" => "313121", "Q" => "211331",
            "R"       => "231131", "S" => "213113", "T" => "213311", "U" => "213131", "V" => "311123",
            "W"       => "311321", "X" => "331121", "Y" => "312113", "Z" => "312311", "[" => "332111",
            "\\"      => "314111", "]" => "221411", "^" => "431111", "_" => "111224", "\`" => "111422",
            "a"       => "121124", "b" => "121421", "c" => "141122", "d" => "141221", "e" => "112214",
            "f"       => "112412", "g" => "122114", "h" => "122411", "i" => "142112", "j" => "142211",
            "k"       => "241211", "l" => "221114", "m" => "413111", "n" => "241112", "o" => "134111",
            "p"       => "111242", "q" => "121142", "r" => "121241", "s" => "114212", "t" => "124112",
            "u"       => "124211", "v" => "411212", "w" => "421112", "x" => "421211", "y" => "212141",
            "z"       => "214121", "{" => "412121", "|" => "111143", "}" => "111341", "~" => "131141",
            "DEL"     => "114113", "FNC 3" => "114311", "FNC 2" => "411113", "SHIFT" => "411311",
            "CODE C"  => "113141", "FNC 4" => "114131", "CODE A" => "311141", "FNC 1" => "411131",
            "Start A" => "211412", "Start B" => "211214", "Start C" => "211232", "Stop" => "2331112"];
        $code_keys   = array_keys($code_array);
        $code_values = array_flip($code_keys);

        /*generate code string*/
        for ($X = 1; $X <= strlen($code); $X++) {
            $activeKey   = substr($code, ($X - 1), 1);
            $code_string .= $code_array[$activeKey];
            $chksum      = ($chksum + ($code_values[$activeKey] * $X));
        }
        $code_string .= $code_array[$code_keys[($chksum - (intval($chksum / 103) * 103))]];
        $code_string = "211214" . $code_string . "2331112";

        /*generate code width*/
        $code_length = 10;
        for ($i = 1; $i <= strlen($code_string); $i++) {
            $code_length = $code_length + (integer)(substr($code_string, ($i - 1), 1));
        }

        /*generate frame*/
        $img_width  = $code_length;
        $img_height = 30;
        $image      = imagecreate($img_width, $img_height);

        $white = imagecolorallocate($image, 255, 255, 255);
        $black = imagecolorallocate($image, 0, 0, 0);

        imagefill($image, 0, 0, $white);

        /*draw stripes*/
        $location = 10;
        for ($position = 1; $position <= strlen($code_string); $position++) {
            $cur_size = $location + (substr($code_string, ($position - 1), 1));

            imagefilledrectangle($image, $location, 0, $cur_size, $img_height, ($position % 2 == 0 ? $white : $black));
            $location = $cur_size;
        }

        return $image;
    }

    /**
     * @param $data
     *
     * @return string
     * @throws \Magento\Framework\Exception\FileSystemException
     * @throws \Zend_Pdf_Exception
     */
    public function getPreviewPdf($data)
    {
        $path = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA)
            ->getAbsolutePath("template.pdf");

        $pdf = $this->getPrintPdfPreview($data);
        $pdf->render();
        $pdf->save($path);
        $file = $this->template->getBaseUrl() . "pub/media/template.pdf";

        return $file;
    }

    public function getQrCode($code)
    {
        $url = "https://api.qrserver.com/v1/create-qr-code/?&size=120x120&data=" . $code;
        $ch  = curl_init($url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
        $raw = curl_exec($ch);
        curl_close($ch);
        $path = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA)
            ->getAbsolutePath("qr_" . $code . ".png");
        if (file_exists($path)) {
            unlink($path);
        }
        $fp = $this->fileFramework->fileOpen($path, 'x');
        $this->fileFramework->fileWrite($fp, $raw);
        $this->fileFramework->fileClose($fp);
        $file = 'qr_' . $code . ".png";

        return $file;
    }

    /**
     * @param $ticket
     * @param $info
     * @return mixed|string
     */
    public function replaceByTicket($ticket, $info)
    {
        $film = $this->_filmFactory->create()->load($ticket->getEventId());
        $array = [];
        if (!empty($ticket->getInformation())) {
            $infos=$ticket->getInformation();
        }
        $array = $this->serialize->unserialize($infos);
        $arrayInfo = $this->information->getDataTicket($array);
        $text      = '';

        switch ($info) {
            case 'film_name':
                $text = $film->getFilmName();
                break;
            case 'location':
                $text = $arrayInfo['location'];
                break;
            case 'date':
                $text = $arrayInfo['date'];
                break;
            case 'qty':
                $text = $ticket->getQty();
                break;
            case 'start_time':
                $text = $arrayInfo['start_time'];
                break;
            case 'code':
                $text = $ticket->getCode();
                break;
            case 'customer_name':
                $text = $ticket->getCustomerName();
                break;
            case 'customer_email':
                $text = $ticket->getCustomerEmail();
                break;
            case 'order_increment_id':
                $text = $ticket->getOrderIncrementId();
                break;
            default:
                break;
        }

        return $text;
    }

    /**
     * Print PDF Template Preview
     *
     * @param array $data
     *
     * @return \Zend_Pdf
     * @throws \Zend_Pdf_Exception
     */
    public function getPrintPdfPreview($data)
    {
        $pdf = new \Zend_Pdf();
        try {
            $params = $data;
            if (isset($data['use_custom_template']) && $data['use_custom_template'] == 0) {
                $model  = $this->_templateFactory->create()->load($data['template_id']);
                $params = $model->getData();
            }

            $coordinates = [];
            if (!empty($params['pdf_coordinates'])) {
                $coordinates = $this->serialize->unserialize($params['pdf_coordinates']);
            }
            if (!empty($params['pdf_background'])) {
                $backgroundLink = $this->serialize->unserialize($params['pdf_background']);
            }

            $fontRegular    = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA);
            $fontBold       = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA_BOLD);
            $fontBoldItalic = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA_BOLD_ITALIC);
            $fontItalic     = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA_ITALIC);
            $width          = $params['pdf_page_width'];
            $height         = $params['pdf_page_height'];

            if ($width && $height) {
                $size = $width . ':' . $height;
            } else {
                $size = "600:400";
            }
            $page = $pdf->newPage($size);
            if (isset($backgroundLink) && !empty($backgroundLink)) {
                $background = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA)
                    ->getAbsolutePath('ticket/template/' . $backgroundLink['0']['file']);
                if (is_file($background)) {
                    $image = \Zend_Pdf_Image::imageWithPath($background);
                    $page->drawImage($image, 0, 0, $width, $height);
                }
            }

            $code = 'MagenestA4vM';
            $page->setFont($fontRegular, 15);
            $tableRowsArr = $coordinates;

            $path = $this->filesystem->getDirectoryRead(
                DirectoryList::MEDIA
            );

            foreach ($tableRowsArr as $param) {
                /**
                 * Insert QR Code to PDF File
                 */
                if (!empty($param['info']) && $param['info'] == 'qr_code' && !empty($param['x']) && !empty($param['y']) && !empty($param['size'])) {
                    $fileName   = $this->getQrCode($code);
                    $pathQrcode = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA)->getAbsolutePath($fileName);
                    $image      = \Zend_Pdf_Image::imageWithPath($pathQrcode);
                    $page->drawImage(
                        $image,
                        $param['x'],
                        $param['y'],
                        $param['x'] + $param['size'],
                        $param['y'] + $param['size']
                    );

                    if ($path->isFile($fileName)) {
                        $this->filesystem->getDirectoryWrite(
                            DirectoryList::MEDIA
                        )->delete($fileName);
                    }

                    continue;
                }

                if (isset($param['info'])) {
                    if ($param['info'] == "film_photo") {
                        $background = $this->filesystem->getDirectoryWrite(DirectoryList::ROOT)
                            ->getAbsolutePath('app/code/Movie/Ticket/view/frontend/web/images/TestFilmPhoto.jpeg');
                        $image      = \Zend_Pdf_Image::imageWithPath($background);
                        $page->drawImage(
                            $image,
                            $param['x'],
                            $param['y'],
                            $param['x'] + $param['size'],
                            $param['y'] + $param['size']
                        );
                    }
                }

                /**
                 * Insert Barcode to PDF File
                 */
                if (!empty($param['info']) && $param['info'] == 'bar_code') {
                    $barcodeOptions  = ['text' => $code, 'drawText' => false];
                    $rendererOptions = [];
                    $magentoVer      = $this->productMetadata->getVersion();
                    if (version_compare($magentoVer, '2.3', '>=')) {
                        $imageResource = $this->generateBarcode($code);
                    } else {
                        $imageResource = \Zend_Barcode::draw('code128', 'image', $barcodeOptions, $rendererOptions);
                    }
                    $barcode = $this->filesystem->getDirectoryWrite(DirectoryList::MEDIA)->getAbsolutePath('barcode.jpg');
                    imagejpeg($imageResource, $barcode, 100);
                    imagedestroy($imageResource);
                    $image = \Zend_Pdf_Image::imageWithPath($barcode);
                    $page->drawImage(
                        $image,
                        $param['x'],
                        $param['y'],
                        $param['x'] + $param['size'] * 2,
                        $param['y'] + $param['size']
                    );
                    if ($path->isFile('barcode.jpg')) {
                        $this->filesystem->getDirectoryWrite(
                            DirectoryList::MEDIA
                        )->delete('barcode.jpg');
                    }

                    continue;
                }

                /**
                 * Insert diffenceinformation
                 */
                if (!empty($param['info']) && !empty($param['x']) && !empty($param['y'])
                    && !empty($param['size']) && !empty($param['color'])) {
                    $text   = $this->replaceByText($param['info']);
                    $format = $fontRegular;
                    if (isset($param['format'])) {
                        switch ($param['format']) {
                            case 'bold':
                                $format = $fontBold;
                                break;
                            case 'italic':
                                $format = $fontItalic;
                                break;
                            case 'bold_italic':
                                $format = $fontBoldItalic;
                                break;
                            default:
                                $format = $fontRegular;
                        }
                    }
                    $page->setFont($format, $param['size']);
                    $color = new \Zend_Pdf_Color_Html($param['color']);
                    $page->setFillColor($color);
                    if (isset($param['title']) && !empty($param['title'])) {
                        $textEnd = $param['title'] . ': ' . $text;
                    } else {
                        $textEnd = $text;
                    }
                    $textEnd=$this->convertStr($textEnd);
                    $textWidth = $this->getTextWidth($textEnd, $format, $param['size']);
                    if (isset($param['align'])) {
                        switch ($param['align']) {
                            case 'center':
                                $textChunk = wordwrap($textEnd, 30, "\n");
                                $line      = $param['y'];
                                foreach (explode("\n", $textChunk) as $textLine) {
                                    if ($textLine !== '') {
                                        $textWidth = $this->getTextWidth($textLine, $format, $param['size']);
                                        $page->drawText(
                                            strip_tags(ltrim($textLine)),
                                            ($param['x'] / 2) - ($textWidth / 2),
                                            $line,
                                            'UTF-8'
                                        );
                                        $line -= $param['size'] + 4;
                                    }
                                }
                                break;
                            case 'right':
                                $page->drawText(
                                    $textEnd,
                                    $param['x'] - $textWidth - $param['size'],
                                    $param['y']
                                );
                                break;

                            default:
                                $page->drawText(
                                    $textEnd,
                                    $param['x'],
                                    $param['y'],
                                    'UTF-8'
                                );
                        }
                    } else {
                        $page->drawText(
                            $textEnd,
                            $param['x'],
                            $param['y'],
                            'UTF-8'
                        );
                    }
                }
            }
            $pdf->pages[] = $page;
        } catch (\Exception $exception) {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $objectManager->get('Psr\Log\LoggerInterface')->critical($exception);
        }

        return $pdf;
    }

    public function getTextWidth($text, $font, $font_size)
    {
        $drawing_text = iconv('', 'utf-8//IGNORE', $text);
        $characters   = [];
        for ($i = 0; $i < strlen($drawing_text); $i++) {
            $characters[] = ord($drawing_text[$i]);
        }
        $glyphs     = $font->glyphNumbersForCharacters($characters);
        $widths     = $font->widthsForGlyphs($glyphs);
        $text_width = (array_sum($widths) / $font->getUnitsPerEm()) * $font_size;

        return $text_width;
    }
    /**
     * @param $info
     *
     * @return string
     */
    public function replaceByText($info)
    {
        $text = '';
        switch ($info) {
            case 'film_name':
                $text = ' The Movie';
                break;
            case 'location':
                $text = 'Số 175 Tây Sơn, Trung Liệt, Đống Đa, Hà Nội, Việt Nam';
                break;
            case 'date':
                $text = '16/11/2016';
                break;
            case 'start_time':
                $text = '9:00';
                break;
            case 'sit':
                $text = 'A1-A2-A3-A4-A5-A6';
                break;
            case 'code':
                $text = 'Moviesa2A4vM';
                break;
            case 'customer_name':
                $text = 'Movie JSC';
                break;
            case 'customer_email':
                $text = 'example@gmail.com';
                break;
            case 'order_increment_id':
                $text = '00000026';
                break;
            case 'qty':
                $text = '1';
                break;
            default:
                break;
        }

        return $text;
    }
    public function convertStr(string $str)
    {
        if (is_string($str)) {
            $str = mb_convert_case($str, MB_CASE_LOWER, "UTF-8");
            $unicode = [
                'a' => 'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ',
                'd' => 'đ',
                'e' => 'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ',
                'i' => 'í|ì|ỉ|ĩ|ị',
                'o' => 'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',
                'u' => 'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',
                'y' => 'ý|ỳ|ỷ|ỹ|ỵ',
                'A' => 'Á|À|Ả|Ã|Ạ|Ă|Ắ|Ặ|Ằ|Ẳ|Ẵ|Â|Ấ|Ầ|Ẩ|Ẫ|Ậ',
                'D' => 'Đ',
                'E' => 'É|È|Ẻ|Ẽ|Ẹ|Ê|Ế|Ề|Ể|Ễ|Ệ',
                'I' => 'Í|Ì|Ỉ|Ĩ|Ị',
                'O' => 'Ó|Ò|Ỏ|Õ|Ọ|Ô|Ố|Ồ|Ổ|Ỗ|Ộ|Ơ|Ớ|Ờ|Ở|Ỡ|Ợ',
                'U' => 'Ú|Ù|Ủ|Ũ|Ụ|Ư|Ứ|Ừ|Ử|Ữ|Ự',
                'Y' => 'Ý|Ỳ|Ỷ|Ỹ|Ỵ',
            ];

            foreach ($unicode as $nonUnicode => $uni) {
                $str = preg_replace("/($uni)/i", $nonUnicode, $str);
            }
            return $str;
        }
        return null;
    }
}
