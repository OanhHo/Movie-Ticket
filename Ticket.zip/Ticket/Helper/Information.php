<?php

namespace Movie\Ticket\Helper;

use Movie\Ticket\Model\DateFactory;
use Movie\Ticket\Model\DateSessionFactory;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;

/**
 * Class Information
 * @package Movie\Ticket\Helper
 */
class Information extends AbstractHelper
{


    /**
     * @var DateFactory
     */
    protected $_date;

    /**
     * @var SessionFactory
     */
    protected $_session;

    /**
     * Date format
     */
    const XML_PATH_DATE_FORMAT = 'event_ticket/general_config/date_format';

    /**
     * Information constructor.
     * @param Context $context
     * @param DateFactory $dateFactory
     */
    public function __construct(
        Context $context,
        DateFactory $dateFactory,
        DateSessionFactory $sessionFactory
    ) {
        $this->_date = $dateFactory;
        $this->_session = $sessionFactory;
        parent::__construct($context);
    }

    /**
     * @param $array
     * @return array
     */
    public function getDataTicket($array)
    {
        $locationTitle = '';
        $locationDetail = '';
        $dateStr = '';
        $startTime = '';
        $endTime = '';
        $dateFormat = $this->scopeConfig->getValue(self::XML_PATH_DATE_FORMAT);
        if (!empty($array['date'])) {
            $date = $this->_date->create()->load($array['date']);
            $start = 'no limit';
            $end = 'no limit';

            if (!empty($date->getDate())) {
                $date = substr($date->getDate(), 0, 10);
                $dateStr = trim(date($dateFormat, strtotime($date)));
            }
        }
        if (!empty($array['session'])) {
            $session = $this->_session->create()->load($array['session']);
            if (!empty($session->getStartTime())) {
                $startTime = 'Start: ' . $session->getStartTime() . ' ';
            }
            if (!empty($session->getEndTime())) {
                $endTime = 'End: ' . $session->getEndTime();
            }
        }

        return $array = [
            'date' => $dateStr,
            'start_time' => $startTime,
            'end_time' => $endTime,
        ];
    }
}
