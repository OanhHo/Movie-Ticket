<?php

namespace Movie\Ticket\Model\Template;
use Movie\Ticket\Model\TemplateFactory;
/**
 * Class DataProvider
 * @package Movie\Ticket\Model
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    protected $_loadedData;

    /**
     * DataProvider constructor.
     *
     * @param TemplateFactory $templateFactory
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        TemplateFactory $templateFactory,
        $name,
        $primaryFieldName,
        $requestFieldName,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $templateFactory->create()->getCollection();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @return array
     */
    public function getData()
    {
        if (isset($this->_loadedData)) {
            return $this->_loadedData;
        }
        $data          = $this->_loadedData;
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $request       = $objectManager->get('Magento\Framework\App\RequestInterface');
        $id            = $request->getParam('template_id');
        /** @var \Magento\Framework\Serialize\Serializer\Serialize $serializer */
        $serializer = $objectManager->get('Magento\Framework\Serialize\Serializer\Serialize');
        if ($id) {
            $model     = $objectManager->create('Movie\Ticket\Model\Template')->load($id);
            $data[$id] = $model->getData();
            if (!empty($data[$id]['pdf_coordinates'])) {
                $data[$id]['pdf_coordinates'] = $serializer->unserialize($data[$id]['pdf_coordinates']);
            }
            if (!empty($data[$id]['pdf_background'])) {
                $data[$id]['pdf_background'] = $serializer->unserialize($data[$id]['pdf_background']);
            }
        }

        return $data;
    }
}
