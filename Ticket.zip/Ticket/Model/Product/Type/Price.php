<?php

namespace Movie\Ticket\Model\Product\Type;

/**
 * Class Price
 * @package Movie\Ticket\Model\Product\Type
 */
class Price extends \Magento\Catalog\Model\Product\Type\Price
{

}
