<?php

namespace Movie\Ticket\Model\Product\Type;

use Magento\Catalog\Model\Product\Type\Virtual;

/**
 * Class FilmTicket
 * @package Movie\Ticket\Model\Product\Type
 */
class FilmTicket extends Virtual
{
    /**
     * Check if product has options
     *
     * @param \Magento\Catalog\Model\Product $product
     * @return boolean
     */
    public function hasOptions($product)
    {
        return true;
    }
}
