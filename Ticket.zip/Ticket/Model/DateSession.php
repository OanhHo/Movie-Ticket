<?php
namespace Movie\Ticket\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * Class DateSession
 * @package Movie\Ticket\Model
 */
class DateSession extends AbstractModel
{
    /**
     * Cache tag
     *
     * @var string
     */
    const CACHE_TAG = 'movie_date_session';

    /**
     * Cache tag
     *
     * @var string
     */
    protected $_cacheTag = 'movie_date_session';

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'movie_date_session';

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Movie\Ticket\Model\ResourceModel\DateSession');
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }
}
