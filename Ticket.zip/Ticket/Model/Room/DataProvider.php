<?php

namespace Movie\Ticket\Model\Room;
use Magento\Framework\Serialize\Serializer\Serialize;
use Movie\Ticket\Model\RoomFactory;
use Movie\Ticket\Model\DateFactory;

/**
 * Class DataProvider
 * @package Movie\Ticket\Model\Room
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    protected $_loadedData;
    /**
     * @var DateFactory
     */
    protected $_dateFactory;
    /**
     * @var RoomFactory
     */
    protected $_roomFactory;
    /**
     * @var Serialize
     */
    protected $serialize;
    /**
     * @var \Magento\Framework\Serialize\Serializer\Json
     */
    protected $_json;

    /**
     * DataProvider constructor.
     * @param RoomFactory $roomFactory
     * @param DateFactory $dateFactory
     * @param $name
     * @param $primaryFieldName
     * @param $requestFieldName
     * @param \Magento\Framework\Serialize\Serializer\Json $json
     * @param Serialize $serialize
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        RoomFactory $roomFactory,
        DateFactory $dateFactory,
        $name,
        $primaryFieldName,
        $requestFieldName,
        \Magento\Framework\Serialize\Serializer\Json $json,
        Serialize $serialize,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $roomFactory->create()->getCollection();
        $this->_dateFactory=$dateFactory;
        $this->_roomFactory=$roomFactory;
        $this->serialize = $serialize;
        $this->_json     = $json;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @return array
     */
    public function getData()
    {
        if (isset($this->_loadedData)) {
            return $this->_loadedData;
        }
        $data          = $this->_loadedData;
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $request       = $objectManager->get('Magento\Framework\App\RequestInterface');
        $id            = $request->getParam('room_id');
        /** @var \Magento\Framework\Serialize\Serializer\Serialize $serializer */
        $serializer = $objectManager->get('Magento\Framework\Serialize\Serializer\Serialize');
        if ($id) {
            $roomModel     = $objectManager->create('Movie\Ticket\Model\Room')->load($id);
            if($roomModel){
                $data[strval($id)]['room_id'] =$id;
                $data[strval($id)]['cinema_id'] =$roomModel->getCinemaId();
                $data[strval($id)]['title'] =$roomModel->getTitle();
                $data[strval($id)]['enabled'] =$roomModel->getEnabled();
                $detail=$roomModel->getDetail();
                if (!empty($detail)) {
                    try{
                        $arrayDetail = $this->_json->unserialize($detail);
                    }catch (\Exception $e){
                        $arrayDetail = $this->serialize->unserialize($detail);
                    }
                    $size      = count($arrayDetail);
                    for ($i = 0; $i < $size; $i++) {
                        $data[strval($id)]['data']['room']['movie_room_sit']['detail'][$i] =
                            [
                                'record_id' => $i,
                                'info'      => $arrayDetail[$i]['info'],
                                'from_number'     => $arrayDetail[$i]['from_number'],
                                'to_number'    => $arrayDetail[$i]['to_number'],
                                'sit_is_enabled'     => isset($arrayDetail[$i]['sit_is_enabled']) ? $arrayDetail[$i]['sit_is_enabled'] : '1',
                            ];
                    }
                }
                /** @var \Movie\Ticket\Model\DateFactory $dateModel */
                $dateModel = $this->_dateFactory->create()->getCollection()
                    ->addFieldToFilter('room_id', $id);
                $arrayDateSession = [];
                foreach ($dateModel as $date) {
                    $dateSessionArray    = [
                        'id_date'         => $date->getDateId(),
                        'time_date_start' => $date->getDateStart(),
                        'time_date_end'   => $date->getDateEnd(),
                        'row_session'     => $this->getSessionData($date->getDateId(),$id),
                        'date_enabled' => $date->getDateIsEnabled()
                    ];
                    $arrayDateSession [] = $dateSessionArray;
                }
                $data[strval($id)]['data']['room']['room_date_session']['room_date']           = $arrayDateSession;
            }

        }

        return $data;
    }

    /**
     * @param $dateId
     * @return array|bool|float|int|mixed|string|null
     */
    public function getSessionData($dateId,$roomId){
        $dateModel = $this->_dateFactory->create()->getCollection()
            ->addFieldToFilter('date_id', $dateId)
            ->addFieldToFilter('room_id',$roomId)
            ->getFirstItem();
        $array = [];
        $session=$dateModel->getSession();
        if (!empty($session)) {
            try{
                $arraySession = $this->_json->unserialize($session);
            }catch (\Exception $e){
                $arraySession = $this->serialize->unserialize($session);
            }
        }
        return $arraySession;
    }

}
