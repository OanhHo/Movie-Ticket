<?php

namespace Movie\Ticket\Model\Config\Source;

/**
 * Class Ticket
 * @package Movie\Ticket\Model\Config\Source
 */
class Ticket implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => __('Generate one ticket'), 'value' => 'gen_one_ticket'],
            ['label' => __('Generate multiple tickets'), 'value' => 'gen_multi_ticket'],
        ];
    }
}
