<?php

namespace Movie\Ticket\Model\Config\Source;

/**
 * Class DateFormat
 * @package Movie\Ticket\Model\Config\Source
 */
class DateFormat implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['label' => __('d-m-Y     ( 30-04-2018 )'), 'value' => 'd-m-Y'],
            ['label' => __('d-m-y     ( 30-04-18 )'), 'value' => 'd-m-y'],
            ['label' => __('m-d-Y     ( 04-30-2018 )'), 'value' => 'm-d-Y'],
            ['label' => __('m-d-y     ( 04-30-18 )'), 'value' => 'm-d-y'],
            ['label' => __('Y-m-d     ( 2018-04-30 )'), 'value' => 'Y-m-d'],
            ['label' => __('Y-d-m     ( 2018-30-04 )'), 'value' => 'Y-d-m'],
            ['label' => __('M jS      ( Apr 30th )'), 'value' => 'M jS'],
            ['label' => __('jS M      ( 30th Apr )'), 'value' => 'jS M'],
            ['label' => __('D, M jS   ( Wed, Apr 30th )'), 'value' => 'D, M jS'],
            ['label' => __('D, jS M   ( Wed, 30th Apr )'), 'value' => 'D, jS M'],
            ['label' => __('M jS Y    ( Apr 30th 2018 )'), 'value' => 'M jS Y'],
            ['label' => __('M jS y    ( Apr 30th 18 )'), 'value' => 'M jS y'],
            ['label' => __('jS M Y    ( 30th Apr 2018 )'), 'value' => 'jS M Y'],
            ['label' => __('jS M y    ( 30th Apr 18 )'), 'value' => 'jS M y'],
            ['label' => __('D, M jS Y ( Wed, Apr 30th 2018 )'), 'value' => 'D, M jS Y'],
            ['label' => __('D, M jS y ( Wed, Apr 30th 18 )'), 'value' => 'D, M jS y'],
        ];
    }
}
