<?php
namespace Movie\Ticket\Model\Config\Source;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\Option\ArrayInterface;
use Movie\Ticket\Model\CinemaFactory;
use Movie\Ticket\Model\RoomFactory;
/**
 * Class SessionList
 * @package Movie\Ticket\Model\Config\Source
 */
class RoomList implements ArrayInterface {

    /**
     * @var CollectionFactory
     */
    protected $_cinemaCollection;
    /**
     * @var RoomFactory
     */
    protected $_roomFactory;

    /**
     * CinemaList constructor.
     * @param CollectionFactory $_collection
     */
    public function __construct(CinemaFactory $cinemaFactory,
                                RoomFactory $roomFactory)
    {
        $this->_cinemaCollection=$cinemaFactory;
        $this->_roomFactory=$roomFactory;
    }

    public function toOptionArray()
    {
        $cinemaModel=$this->_cinemaCollection->create()->getCollection();
        $array=[];
        foreach ($cinemaModel as $cinema){
            $roomModel=$this->_roomFactory->create()->getCollection()
                ->addFieldToFilter('cinema_id',$cinema['cinema_id']);
            foreach ($roomModel as $room){
                $array[]=[
                    'value'=>$room['room_id'], 'label'=>$room['title']."-".$cinema['name']
                ];
            }

        }
        return $array;
    }
}