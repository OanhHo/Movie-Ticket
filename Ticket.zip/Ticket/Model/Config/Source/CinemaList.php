<?php
namespace Movie\Ticket\Model\Config\Source;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\Option\ArrayInterface;
use Movie\Ticket\Model\CinemaFactory;
/**
 * Class CinemaList
 * @package Movie\Ticket\Model\Config\Source
 */
class CinemaList implements ArrayInterface {

    /**
     * @var CollectionFactory
     */
    protected $_cinemaCollection;

    /**
     * CinemaList constructor.
     * @param CollectionFactory $_collection
     */
    public function __construct(CinemaFactory $cinemaFactory)
    {
        $this->_cinemaCollection=$cinemaFactory;
    }

    public function toOptionArray()
    {
        $cinema=$this->_cinemaCollection->create()->getCollection();
        $array=[];
        foreach ($cinema as $value){
            $array[]=[
                'value'=>$value['cinema_id'], 'label'=>$value['name']
            ];
        }
        return $array;
    }
}