<?php
namespace Movie\Ticket\Model\Config\Source;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Framework\Option\ArrayInterface;
use Magento\Framework\Serialize\Serializer\Serialize;
use Movie\Ticket\Model\CinemaFactory;
use Movie\Ticket\Model\RoomFactory;
use Movie\Ticket\Model\DateFactory;
/**
 * Class SessionList
 * @package Movie\Ticket\Model\Config\Source
 */
class SessionList implements ArrayInterface {

    /**
     * @var CollectionFactory
     */
    protected $_cinemaCollection;
    /**
     * @var RoomFactory
     */
    protected $_roomFactory;
    /**
     * @var DateFactory
     */
    protected $_dateFactory;
    /**
     * @var Serialize
     */
    protected $serialize;
    /**
     * @var ResolverInterface
     */
    protected $resolver;
    /**
     * SessionList constructor.
     * @param CinemaFactory $cinemaFactory
     * @param RoomFactory $roomFactory
     * @param DateFactory $dateFactory
     */
    public function __construct(CinemaFactory $cinemaFactory,
                                RoomFactory $roomFactory,
                                DateFactory $dateFactory,
                                Serialize $serialize,
                                ResolverInterface $resolverInterface)
    {
        $this->_cinemaCollection=$cinemaFactory;
        $this->_roomFactory=$roomFactory;
        $this->_dateFactory=$dateFactory;
        $this->serialize   = $serialize;
        $this->resolver=$resolverInterface;
    }

    public function toOptionArray()
    {
        $modelRoom=$this->_roomFactory->create()->getCollection();
        $array=[];
        $today = date("Y-m-d");
        $start = date_create($today);
        $start = date_format($start, "Y-m-d");
        $end = date_create($today);
        date_modify($end, "+02 days");
        $end = date_format($end, "Y-m-d");
        foreach ($modelRoom as $room){
            $modelDate=$this->_dateFactory->create()->getCollection()
                ->addFieldToFilter('room_id',$room['room_id']);
            $cinemaModel=$this->_cinemaCollection->create()->getCollection()
                ->addFieldToFilter('cinema_id',$room['cinema_id'])
                ->getFirstItem();
            foreach ($modelDate as $date){
                $dateSession=$this->serialize->unserialize($date->getDateSession());
                $size=count($dateSession);
                for ($i = 0; $i < $size; $i++) {
                    $dateTime=$dateSession[$i]['date'];
                    $dateTime=date_create($dateTime);
                    $dateTime=date_format($dateTime,'Y-m-d');
                    if($start<$dateTime && $end>=$dateTime){
                        if ($dateSession[$i]['session_is_enabled'] ==1){
                            $array[]=[
                                'value'=>$date['date_id']."-".$room['room_id']."-".$dateSession[$i]['date']."-".$dateSession[$i]['start_time']."-".$room['cinema_id'],
                                'label'=>"Cinema: ".$cinemaModel->getName()." - Room: ".$room['title']." - Date: ".$dateSession[$i]['date']." - DateSession: ".$dateSession[$i]['start_time']
                            ];
                        }
                    }


                }
            }


        }
        return $array;
    }
}