<?php

namespace Movie\Ticket\Model\Config\Source\Product\Options;

/**
 * Class Info
 * @package Movie\Ticket\Model\Config\Source\Product\Options
 */
class Info implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [
            ['label' => __('Film Name'), 'value' => 'film_name'],
            ['label' => __('Location'), 'value' => 'location'],
            ['label' => __('QR Code'), 'value' => 'qr_code'],
            ['label' => __('Bar Code'), 'value' => 'bar_code'],
            ['label' => __('Code'), 'value' => 'code'],
            ['label' => __('Date'), 'value' => 'date'],
            ['label' => __('Start Time'), 'value' => 'start_time'],
            ['label' => __('Sit'), 'value' => 'sit'],
            ['label' => __('Customer Name'), 'value' => 'customer_name'],
            ['label' => __('Customer Email'), 'value' => 'customer_email'],
            ['label' => __('Order #'), 'value' => 'order_increment_id']
        ];
    }
}
