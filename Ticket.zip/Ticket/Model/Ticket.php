<?php
namespace Movie\Ticket\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * Class Ticket
 * @package Movie\Ticket\Model
 */
class Ticket extends AbstractModel
{
    /**
     * Cache tag
     * @var string
     */
    const CACHE_TAG = 'movie_ticket';

    /**
     * Cache tag
     * @var string
     */
    protected $_cacheTag = 'movie_ticket';

    /**
     * Event prefix
     * @var string
     */
    protected $_eventPrefix = 'movie_ticket';

    protected $_filmFactory;
    /**
     * Initialize resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Movie\Ticket\Model\ResourceModel\Ticket');
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }
}
