<?php
namespace Movie\Ticket\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * Class Date
 * @package Movie\Ticket\Model
 */
class Date extends AbstractModel
{
    /**
     * Cache tag
     *
     * @var string
     */
    const CACHE_TAG = 'movie_date';

    /**
     * Cache tag
     *
     * @var string
     */
    protected $_cacheTag = 'movie_date';

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'movie_date';

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Movie\Ticket\Model\ResourceModel\Date');
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }
}
