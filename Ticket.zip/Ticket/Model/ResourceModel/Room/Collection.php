<?php
namespace Movie\Ticket\Model\ResourceModel\Room;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @package Movie\Ticket\Model\ResourceModel\Room
 */
class Collection extends AbstractCollection
{
    /**
     * ID Field Name
     *
     * @var string
     */
    protected $_idFieldName = 'room_id';

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'movie_room_collection';

    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'room_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Movie\Ticket\Model\Room', 'Movie\Ticket\Model\ResourceModel\Room');
    }
}
