<?php

namespace Movie\Ticket\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\Stdlib\DateTime as LibDateTime;

/**
 * Class Template
 * @package Movie\Ticket\Model\ResourceModel
 */
class Template extends AbstractDb
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('movie_ticket_template', 'template_id');
    }
}
