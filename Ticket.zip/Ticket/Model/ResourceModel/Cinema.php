<?php
namespace Movie\Ticket\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class Cinema
 * @package Movie\Ticket\Model\ResourceModel
 */
class Cinema extends AbstractDb
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('movie_cinema', 'cinema_id');
    }
}
