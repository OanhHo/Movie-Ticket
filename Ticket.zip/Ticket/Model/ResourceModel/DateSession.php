<?php
namespace Movie\Ticket\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class DateSession
 * @package Movie\Ticket\Model\ResourceModel
 */
class DateSession extends AbstractDb
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('movie_date_session', 'session_id');
    }
}
