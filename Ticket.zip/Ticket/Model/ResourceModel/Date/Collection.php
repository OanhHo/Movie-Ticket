<?php
namespace Movie\Ticket\Model\ResourceModel\Date;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @package Movie\Ticket\Model\ResourceModel\Date
 */
class Collection extends AbstractCollection
{
    /**
     * ID Field Name
     *
     * @var string
     */
    protected $_idFieldName = 'date_id';

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'movie_date_collection';

    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'date_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Movie\Ticket\Model\Date', 'Movie\Ticket\Model\ResourceModel\Date');
    }
}
