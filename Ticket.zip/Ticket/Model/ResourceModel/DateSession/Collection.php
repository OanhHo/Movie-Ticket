<?php
namespace Movie\Ticket\Model\ResourceModel\DateSession;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @package Movie\Ticket\Model\ResourceModel\DateSession
 */
class Collection extends AbstractCollection
{
    /**
     * ID Field Name
     *
     * @var string
     */
    protected $_idFieldName = 'session_id';

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'movie_date_session_collection';

    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'date_session_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Movie\Ticket\Model\DateSession', 'Movie\Ticket\Model\ResourceModel\DateSession');
    }
}
