<?php
namespace Movie\Ticket\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class Location
 * @package Movie\Ticket\Model\ResourceModel
 */
class Location extends AbstractDb
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('movie_location', 'location_id');
    }
}
