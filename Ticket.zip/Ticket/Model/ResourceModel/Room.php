<?php
namespace Movie\Ticket\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class Room
 * @package Movie\Ticket\Model\ResourceModel
 */
class Room extends AbstractDb
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('movie_room', 'room_id');
    }
}
