<?php
namespace Movie\Ticket\Model\ResourceModel\Location;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @package Movie\Ticket\Model\ResourceModel\Location
 */
class Collection extends AbstractCollection
{
    /**
     * ID Field Name
     *
     * @var string
     */
    protected $_idFieldName = 'location_id';

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'movie_location_collection';

    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'location_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Movie\Ticket\Model\Location', 'Movie\Ticket\Model\ResourceModel\Location');
    }
}
