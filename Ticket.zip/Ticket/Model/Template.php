<?php

namespace Movie\Ticket\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * Class Template
 * @package Movie\Ticket\Model
 */
class Template extends AbstractModel
{
    /**
     * Cache tag
     *
     * @var string
     */
    const CACHE_TAG = 'movie_ticket_template';

    /**
     * Cache tag
     *
     * @var string
     */
    protected $_cacheTag = 'movie_ticket_template';

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'movie_ticket_template';


    /**
     * type old template
     * @var string
     */
    const TYPE_OLD = 0;

    /**
     * type new template
     * @var string
     */
    const TYPE_NEW = 1;


    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Movie\Ticket\Model\ResourceModel\Template');
    }
}
