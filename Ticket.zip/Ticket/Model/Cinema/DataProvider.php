<?php

namespace Movie\Ticket\Model\Cinema;

/**
 * Class DataProvider
 * @package Movie\Ticket\Model\Cinema
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    protected $_loadedData;

    /**
     * DataProvider constructor.
     * @param \Movie\Ticket\Model\CinemaFactory $cinemaFactory
     * @param $name
     * @param $primaryFieldName
     * @param $requestFieldName
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        \Movie\Ticket\Model\CinemaFactory $cinemaFactory,
        $name,
        $primaryFieldName,
        $requestFieldName,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $cinemaFactory->create()->getCollection();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @return array
     */
    public function getData()
    {
        if (isset($this->_loadedData)) {
            return $this->_loadedData;
        }
        $data          = $this->_loadedData;
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $request       = $objectManager->get('Magento\Framework\App\RequestInterface');
        $id            = $request->getParam('cinema_id');
        if ($id) {
            $model     = $objectManager->create('Movie\Ticket\Model\Cinema')->load($id);
            $data[$id] = $model->getData();
        }

        return $data;
    }
}
