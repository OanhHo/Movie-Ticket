<?php

namespace Movie\Ticket\Observer\Option;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Serialize\Serializer\Json;

/**
 * Class Cart
 * @package Movie\Ticket\Observer\Option
 */
class Cart implements ObserverInterface
{
    /**
     * Date format
     */
    const XML_PATH_DATE_FORMAT = 'movie_ticket/general_config/date_format';

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @var \Magento\Directory\Model\Currency
     */
    protected $_currency;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Movie\Ticket\Model\DateSessionFactory
     */
    protected $session;

    /**
     * @var \Magento\Catalog\Model\ProductRepository
     */
    protected $_productRepository;

    /**
     * @var \Movie\Ticket\Model\DateFactory
     */
    protected $date;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var Json
     */
    protected $serialize;
    /**
     * @var \Movie\Ticket\Model\RoomFactory
     */
    protected $_room;
    /**
     * @var \Movie\Ticket\Model\FilmFactory
     */
    protected $film;
    /**
     * @var \Movie\Ticket\Model\CinemaFactory
     */
    protected $cinema;

    /**
     * Cart constructor.
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Directory\Model\Currency $currency
     * @param \Movie\Ticket\Model\RoomFactory $roomFactory
     * @param \Movie\Ticket\Model\FilmFactory $filmFactory
     * @param \Movie\Ticket\Model\CinemaFactory $cinemaFactory
     * @param \Movie\Ticket\Model\DateFactory $dateFactory
     * @param \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Catalog\Model\ProductRepository $productRepository
     * @param Json $serialize
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\Directory\Model\Currency $currency,
        \Movie\Ticket\Model\RoomFactory $roomFactory,
        \Movie\Ticket\Model\FilmFactory $filmFactory,
        \Movie\Ticket\Model\CinemaFactory $cinemaFactory,
        \Movie\Ticket\Model\DateFactory $dateFactory,
        \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        Json $serialize
    ) {
        $this->_productRepository = $productRepository;
        $this->_room             = $roomFactory;
        $this->film         = $filmFactory;
        $this->_logger            = $logger;
        $this->_currency          = $currency;
        $this->_request           = $request;
        $this->cinema           = $cinemaFactory;
        $this->date               = $dateFactory;
        $this->_scopeConfig       = $scopeConfig;
        $this->session            = $dateSessionFactory;
        $this->serialize          = $serialize;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        try {
            $item             = $observer->getEvent()->getQuoteItem();
            $product          = $item->getProduct();
            $productId        = $product->getId();
            $data             = $this->_request->getParams();
            $dateFormat       = $this->_scopeConfig->getValue(self::XML_PATH_DATE_FORMAT);
            $checkTypeProduct = $this->_productRepository->getById($productId)->getTypeId();
            if ($checkTypeProduct == 'film') {
                if (!empty($data['additional_options'])) {
                    $options           = $data['additional_options'];
                    $additionalOptions = [];
                    if (!empty($data['additional_options']['ticket_price'])) {

                        $item->setOriginalCustomPrice($options['ticket_price']);
                    }
                    $cinemaId = '';
                    $sessionId  = '';
                    if (isset($options['single']) && !empty($options['single'])) {
                        if (!empty($options['single']['ticket_location'])) {
                            $cinemaId = $options['single']['ticket_location'];
                        }
                        if (!empty($options['single']['ticket_session'])) {
                            $sessionId = $options['single']['ticket_session'];
                        }
                    } else {
                        if (isset($options['ticket_location']) && !empty($options['ticket_location'])) {
                            $cinemaId = $options['ticket_location'];
                        }

                        if (isset($options['ticket_session']) && !empty($options['ticket_session'])) {
                            $sessionId = $options['ticket_session'];
                        }
                    }

                    if (!empty($cinemaId)) {
                        $cinema = $this->cinema->create()->load($cinemaId);

                        $additionalOptions[] = array(
                            'label' => 'Cinema',
                            'value' => $cinema->getName()
                        );
                    }
                    if (!empty($sessionId)) {
                        $session   = $this->session->create()->load($sessionId);
                        $startTime = '';
                        if (!empty($session->getTime())) {
                            $startTime = 'Start: ' . $session->getTime() . ' ';
                        }
                        if (!empty($session->getDate())) {
                            $date = substr($session->get(), 0, 10);
                            $date     = trim(date($dateFormat, strtotime($date)));
                        }
                        $time                = $startTime;
                        $additionalOptions['date'][] = array(
                            'label' => 'Date',
                            'value' => $date
                        );
                        $additionalOptions['session'][] = array(
                            'label' => 'Time',
                            'value' => $time
                        );
                    }

                    if (!empty($data['ticket_info'])) {
                        $additionalOptions[] = array(
                            'label' => 'info',
                            'value' => $data['ticket_info']
                        );
                    }
                    $check = class_exists('Magento\Framework\Serialize\Serializer\Json');
                    if ($check) {
                        $item->addOption(array(
                            'code'  => 'additional_options',
                            'value' => json_encode($additionalOptions)
                        ));
                    } else {
                        $item->addOption(array(
                            'code'  => 'additional_options',
                            'value' => $this->serialize->serialize($additionalOptions)
                        ));
                    }
                }
            }
        } catch (\Exception $exception) {
            \Magento\Framework\App\ObjectManager::getInstance()->get('Psr\Log\LoggerInterface')->critical($exception);
        }
    }
}
