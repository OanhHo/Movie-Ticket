<?php

namespace Movie\Ticket\Observer\Layout;

use Magento\Framework\Event\ObserverInterface;

/**
 * Class Load
 * @package Movie\Ticket\Observer\Layout
 */
class Load implements ObserverInterface
{
    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $fullActionName = $observer->getEvent()->getFullActionName();
        /** @var  $layout \Magento\Framework\View\Layout */
        $layout = $observer->getEvent()->getLayout();
        $handler = '';
        if ($fullActionName == 'catalog_product_view') {
            $productId = \Magento\Framework\App\ObjectManager::getInstance()
                ->get(\Magento\Framework\App\RequestInterface::class)->getParam("id");
            if ($productId) {
                $eventId = \Magento\Framework\App\ObjectManager::getInstance()
                    ->get(\Movie\Ticket\Helper\Film::class)->isFilm($productId);
                if ($eventId) {
                    $handler = 'catalog_product_view_ticket';
                }
            }
        }
        if ($handler) {
            $layout->getUpdate()->addHandle($handler);
        }
    }
}
