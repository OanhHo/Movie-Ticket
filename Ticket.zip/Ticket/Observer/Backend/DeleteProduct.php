<?php

namespace Movie\Ticket\Observer\Backend;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;

/**
 * Class DeleteProduct
 * @package Movie\Ticket\Observer\Backend
 */
class DeleteProduct implements ObserverInterface
{
    /**
     * @var \Movie\Ticket\Model\FilmFactory
     */
    protected $_filmFactory;

    /**
     * DeleteProduct constructor.
     * @param \Movie\Ticket\Model\FilmFactory $filmFactory
     */
    public function __construct(
        \Movie\Ticket\Model\FilmFactory $filmFactory
    ) {
        $this->_filmFactory = $filmFactory;
    }

    /**
     * @param Observer $observer
     *
     * @throws \Exception
     */
    public function execute(Observer $observer)
    {
        $productId = $observer->getProduct()->getEntityId();
        $event     = $this->_filmFactory->create()->loadByProductId($productId);
        $event->delete();
    }
}
