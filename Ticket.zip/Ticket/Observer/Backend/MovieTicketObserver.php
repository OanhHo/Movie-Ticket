<?php

namespace Movie\Ticket\Observer\Backend;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Psr\Log\LoggerInterface;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\UrlInterface;
use Magento\Framework\App\Cache\TypeListInterface;
use Movie\Ticket\Model\Film;
use Movie\Ticket\Model\FilmFactory;
use Movie\Ticket\Model\DateFactory;
use Movie\Ticket\Model\DateSessionFactory;
use Magento\Framework\Serialize\Serializer\Serialize;

/**
 * Class MovieTicketObserver
 * @package Movie\Ticket\Observer\Backend
 */
class MovieTicketObserver implements ObserverInterface
{
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var LoggerInterface
     */
    protected $_logger;

    /**
     * @var Filesystem
     */
    protected $_filesystem;

    /**
     * @var UploaderFactory
     */
    protected $_fileUploaderFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManage;

    /**
     * @var ResolverInterface
     */
    protected $resolver;

    /**
     * @var Context
     */
    protected $context;

    /**
     * @var ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    private $messageManager;

    /**
     * @var Json
     */
    protected $serialize;
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlInterface;

    /**
     * @var TypeListInterface
     */
    protected $cacheTypeList;
    /**
     * @var FilmFactory
     */
    protected $_filmFactory;
    /**
     * @var DateFactory
     */
    protected $_dateFactory;
    /**
     * @var DateSessionFactory
     */
    protected $_dateSessionFactory;

    /**
     * MovieTicketObserver constructor.
     * @param Filesystem $filesystem
     * @param UploaderFactory $fileUploaderFactory
     * @param StoreManagerInterface $storeManagerInterface
     * @param LoggerInterface $logger
     * @param ResolverInterface $resolverInterface
     * @param Context $context
     * @param Serialize $serialize
     * @param ProductMetadataInterface $productMetadata
     * @param UrlInterface $urlInterface
     * @param TypeListInterface $cacheTypeList
     * @param FilmFactory $filmFactory
     * @param SessionFactory $sessionFactory
     * @param DateFactory $dateFactory
     * @param DateSessionFactory $dateSessionFactory
     */
    public function __construct(
        Filesystem $filesystem,
        UploaderFactory $fileUploaderFactory,
        StoreManagerInterface $storeManagerInterface,
        LoggerInterface $logger,
        ResolverInterface $resolverInterface,
        Context $context,
        Serialize $serialize,
        ProductMetadataInterface $productMetadata,
        UrlInterface $urlInterface,
        TypeListInterface $cacheTypeList,
        FilmFactory $filmFactory,
        DateFactory $dateFactory,
        DateSessionFactory $dateSessionFactory

    ) {
        $this->messageManager       = $context->getMessageManager();
        $this->storeManage          = $storeManagerInterface;
        $this->_request             = $context->getRequest();
        $this->_filesystem          = $filesystem;
        $this->_logger              = $logger;
        $this->resolver             = $resolverInterface;
        $this->context              = $context;
        $this->serialize            = $serialize;
        $this->productMetadata      = $productMetadata;
        $this->urlInterface         =$urlInterface;
        $this->cacheTypeList        =$cacheTypeList;
        $this->_filmFactory         =$filmFactory;
        $this->_dateFactory         =$dateFactory;
        $this->_dateSessionFactory  =$dateSessionFactory;
    }

    /**
     * Set new customer group to all his quotes
     *
     * @param Observer $observer
     *
     * @return void
     * @throws \Exception
     */
    public function execute(Observer $observer)
    {
        /** @var \Magento\Catalog\Model\Product $product */
        $product       = $observer->getEvent()->getProduct();
        $productId     = $product->getId();
        $status        = $product->getStatus();
        $productTypeId = $product->getTypeId();
        $params        = $this->_request->getParams();

        if (isset($params['film']) && $productTypeId == Film::PRODUCT_TYPE) {
            $magentoVer = $this->productMetadata->getVersion();
            if (isset($params['sources']) && version_compare($magentoVer, '2.3', '>=')) {
                $totalQty = $this->checkQty($product, $params['sources']);
            } else {
                $totalQty = $product->getStockData();
                $totalQty = isset($totalQty['qty']) ? $totalQty['qty'] : 0;
            }

            $data  = $params['film'];
            $model = $this->_filmFactory->create()->load($productId, 'product_id');

            /* When duplicating event product, unset ID field to save as new event instead of overriding current event entity */
            if (isset($params['back']))
                if ($params['back'] == 'duplicate' && empty($model->getData())) {
                    $data = $this->handleDuplicate($data);
                    $this->messageManager->addNoticeMessage('Please setup session  for duplicated product.');
                }

            $data['product_id']          = $productId;
            $data['film_name']          = $product->getName();
            $data['use_custom_template'] = $params['film']['pdftemplate']['use_custom_template'];


            if ($params['film']['pdftemplate']['use_custom_template'] == 1) {
                $result = [];
                if (isset($params['film']['pdftemplate']['coordinates'])) {
                    $coordinates = $params['film']['pdftemplate']['coordinates'];
                    if (isset($coordinates) && !empty($coordinates)) {
                        $size = count($coordinates);
                        for ($i = 0; $i < $size; $i++) {
                            if ($coordinates[$i]["x"] > $params["film"]["pdftemplate"]["page_width"]) {
                                $coordinates[$i]["x"] = 0;
                                $this->messageManager->addNoticeMessage(__('Ticket template: Coordinate X cannot exceed the Page Width.'));
                            }
                            if ($coordinates[$i]["y"] > $params["film"]["pdftemplate"]["page_height"]) {
                                $coordinates[$i]["y"] = 0;
                                $this->messageManager->addNoticeMessage(__('Ticket template: Coordinate Y cannot exceed the Page Height.'));
                            }
                        }
                        unset($coordinates);
                    }
                }

            } else {
                $data['template_id'] = isset($params['film']['pdftemplate']['template_id']) ? $params['film']['pdftemplate']['template_id'] : '';
            }
            if (isset($params['film']['apply_all_schedule']) && $params['film']['apply_all_schedule'] == 1) {
                if (!empty($params['film']['date-session']['session'])) {
                    $session=$params['film']['date-session']['session'];
                    $size=count($session);
                    for($i=0; $i<$size; $i++){
                        $this->saveSession($session[$i], $productId);
                    }

                } else {
                    $this->removeSessionsByProductId($productId);
                }
            }
            $data['genre'] = isset($params['film']['genre']) ? $params['film']['genre'] : '';
            $data['cast'] = isset($params['film']['cast']) ? $params['film']['cast'] : '';
            $data['director'] = isset($params['film']['director']) ? $params['film']['director'] : '';
            $data['runtime'] = isset($params['film']['runtime']) ? $params['film']['runtime'] : '';
            $data['rated'] = isset($params['film']['rated']) ? $params['film']['rated'] : '';
            $data['detail'] = isset($params['film']['detail']) ? $params['film']['detail'] : '';
            $data['trailer'] = isset($params['film']['trailer']) ? $params['film']['trailer'] : '';
            $data['in_theater'] = isset($params['film']['in_theater']) ? $params['film']['in_theater'] : '';

            $data['enable']               = $status;
            $data['allow_register']       = 1;
            $data['is_register_required'] = 1;
            $data['term']                 = isset($params['film']['terms-conditions']['term']) ?
                $params['film']['terms-conditions']['term'] : '';
            $model->addData($data);
            $model->save();
            try {
                $model->save();
                $this->cacheTypeList->invalidate('full_page');
            }catch (\Exception $e){
                $this->_logger->error($e->getMessage());
            }
            $data['film_id'] = $model->getId();
        }
    }

    /**
     * @param array $data
     *
     * @return array
     */
    public function handleDuplicate($data)
    {
        unset($data['event_id']);
        if (!empty($data['event_schedule']))
            foreach ($data['event_schedule'] as $keyLoc => $fieldLoc) {
                $data['event_schedule'][$keyLoc]['id_location'] = '';
                if (!empty($fieldLoc['row_day']))
                    foreach ($fieldLoc['row_day'] as $keyDate => $fieldDate) {
                        $data['event_schedule'][$keyLoc]['row_day'][$keyDate]['id_date'] = '';
                        if (!empty($fieldDate['row_session']))
                            foreach ($fieldDate['row_session'] as $keySession => $fieldSession) {
                                $data['event_schedule'][$keyLoc]['row_day'][$keyDate]['row_session'][$keySession]['id_session'] = '';
                                $data['event_schedule'][$keyLoc]['row_day'][$keyDate]['row_session'][$keySession]['limit_qty']  = '0';
                                $data['event_schedule'][$keyLoc]['row_day'][$keyDate]['row_session'][$keySession]['qty']        = 0;
                            }
                    }
            }

        return $data;
    }

    /**
     * Check Qty on Magento 2.3 MSI
     *
     * @param \Magento\Catalog\Model\Product $product
     * @param $sources
     *
     * @return null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function checkQty($product, $sources)
    {
        $websiteCode = $this->storeManage->getWebsite(1)->getCode();
        /** @var  \Magento\InventorySales\Model\ResourceModel\GetAssignedStockIdForWebsite $getAssignedStockId */
        $getAssignedStockId = ObjectManager::getInstance()
            ->create('Magento\InventorySales\Model\ResourceModel\GetAssignedStockIdForWebsite');
        $websiteStockId     = $getAssignedStockId->execute($websiteCode); /*get default website's stock Id*/

        $qty = null;
        if (!empty($sources['assigned_sources'])) {
            foreach ($sources['assigned_sources'] as $source) { /*get stock qty per valid source*/
                if (isset($source['source_code'])) {
                    $sourceCode = $source['source_code'];
                    if (isset($source['status']))
                        if ($this->validateSource($websiteStockId, $sourceCode) && $source['status'] == 1) {
                            $qty += isset($source['quantity']) ? $source['quantity'] : '';
                        }
                }
            }
        }

        $currentQty = $product->getStockData();
        $currentQty = isset($currentQty['qty']) ? $currentQty['qty'] : null;

        if ($product->isAvailable()) {
            $currentSalableQty = $this->getSalableQty($product->getSku());
            if (isset($currentQty) && isset($currentSalableQty)) {
                $pendingQty = $currentQty - $currentSalableQty; /*sold but not delivered qty*/
                $qty        = $pendingQty > 0 ? $qty - $pendingQty : $qty; /*get updated salable qty*/
            }
        }

        return $qty;
    }
    /**
     * @param $productId
     */
    protected function removeSessionsByProductId($productId)
    {
        $this->_dateSessionFactory->create()->getCollection()
            ->addFieldToFilter('product_id', $productId)->walk('delete');
    }
    /**
     * @param $sku
     *
     * @return int
     */
    public function getSalableQty($sku)
    {
        $getProductSalableQty         = ObjectManager::getInstance()
            ->create('Magento\InventorySalesApi\Api\GetProductSalableQtyInterface');
        $getStockItemConfiguration    = ObjectManager::getInstance()
            ->create('Magento\InventoryConfigurationApi\Api\GetStockItemConfigurationInterface');
        $storeManager                 = ObjectManager::getInstance()
            ->create('Magento\Store\Model\StoreManagerInterface');
        $websiteCode                  = $storeManager->getWebsite(1)->getCode();
        $getAssignedStockIdForWebsite = ObjectManager::getInstance()
            ->create('Magento\InventorySales\Model\ResourceModel\GetAssignedStockIdForWebsite');

        $websiteStockId         = $getAssignedStockIdForWebsite->execute($websiteCode); /*get default website's stock Id*/
        $stockItemConfiguration = $getStockItemConfiguration->execute($sku, $websiteStockId);
        $isManageStock          = $stockItemConfiguration->isManageStock(); /*check if stock is in use*/
        $stockQty               = $isManageStock ? $getProductSalableQty->execute($sku, $websiteStockId) : 0; /*get salable qty of product's valid stock*/
        $qty                    = $stockQty;

        return $qty;
    }

    /**
     * @param $stockId
     * @param $sourceCode
     *
     * @return bool
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function validateSource($stockId, $sourceCode)
    {
        /** @var \Magento\InventoryApi\Api\GetSourcesAssignedToStockOrderedByPriorityInterface $getSourceAPI */
        $getSourceAPI = ObjectManager::getInstance()->create('Magento\InventoryApi\Api\GetSourcesAssignedToStockOrderedByPriorityInterface');
        $sources      = $getSourceAPI->execute($stockId);

        foreach ($sources as $source) {
            if ($sourceCode == $source->getSourceCode())
                return true;
        }

        return false;
    }

//    /**
//     * @param $productId
//     */
//    protected function removeSessionsByProductId($productId)
//    {
//        $this->_dateSessionFactory->create()->getCollection()
//            ->addFieldToFilter('product_id', $productId)->walk('delete');
//    }

    /**
     * @param $session
     * @param $productId
     * @throws \Exception
     */
    public function saveSession($session, $productId)
    {

            if (!isset($once)) {
                $once = true;
            }
            if (array_key_exists('delete_session', $session)) {
                $modelSession = $this->_dateSessionFactory->create()->load($session['session_id']);
                $modelSession->delete();
            } else {
                if ($once) {
                    $deletedSessions = $this->getDeletedItem('session', $session, $productId, $idDate=null);
                    foreach ($deletedSessions as $sessions) {
                        $this->_dateSessionFactory->create()->load($sessions)->delete();
                    }
                    $once = false;
                }
            }
            $modelSession = $this->_dateSessionFactory->create();
            $info=explode("-",$session['info']);
            $data['product_id']    = $productId;
            $data['date_id'] = $info[0];
            $data['room_id']=$info[1];
            $data['date']   =$info[2];
            $data['time']    = $info[3];
            $data['cinema_id']    = $info[4];
            $data['qty'] = $session['qty'];
            $data['qty_purchase'] = $session['qty_purchase'];
            $data['session_is_enabled'] = $session['session_is_enabled'];
            $modelSession->addData($data)->save();
            $modelDate=$this->_dateFactory->create()->load($modelSession->getDateId());
            $date_session=$this->serialize->unserialize($modelDate->getDateSession());
            $size=count($date_session);
            for ($i=0; $i<$size; $i++ ){
                if(($date_session[$i]['date']==$info[2]) && ($date_session[$i]['start_time']==$info[3])){
                    $date_session[$i]['session_is_enabled']="0";
                }
            }
            $dataDate=$this->serialize->serialize($date_session);
            $_data = array('date_session'=>$dataDate);
            $modelDate->addData($_data);
            $modelDate->save();
//            $test=$this->serialize->unserialize($modelDate->getDateSession());
    }

    /**
     * @param $sameDay
     * @param $rowSession
     *
     * @return bool|string
     */
    public function validateTime($sameDay, $rowSession)
    {
        foreach ($rowSession as $row) {
            $startTime = isset($row['start_time']) ? $row['start_time'] : null;
            $endTime   = isset($row['end_time']) ? $row['end_time'] : null;
            if (empty($startTime)) {
                return 'Start Time is empty.';
            }
            if (empty($endTime)) {
                return 'End Time is empty.';
            }
            if (!preg_match("/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/", $startTime) ||
                !preg_match("/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/", $endTime)) {
                return "Wrong format time. Please use HH:mm (24 hours) format.";
            }
            if ($sameDay && strtotime($startTime) > strtotime($endTime)) {
                return "End Time is earlier than Start Time";
            }

            $hour = explode(":", $startTime);
            if ($hour[0] > 23) {
                return $startTime;
            }
            $hour = explode(":", $endTime);
            if ($hour[0] > 23) {
                return $endTime;
            }
        }

        return true;
    }

    /**
     * @param $type
     * @param $data
     * @param $productId
     * @param null $locationId
     * @param null $dateId
     * @param null $optionId
     *
     * @return array|null
     */
    public function getDeletedItem($type, $data, $productId, $dateId = null)
    {
        switch ($type) {
            case 'session':
            {
                $currentRecord = [];
                $oldRecord     = [];
                foreach ($data as $date) {
                    if (empty($date['id_session'])) {
                        continue;
                    }
                    array_push($currentRecord, intval($date['id_session']));
                }
                $oldScheduleCollections = $this->_dateSessionFactory->create()->getCollection()
                    ->addFieldToFilter('product_id', $productId)
                    ->addFieldToFilter('date_id', $dateId);
                foreach ($oldScheduleCollections as $sessions) {
                    array_push($oldRecord, intval($sessions->getSessionId()));
                }

                return array_diff($oldRecord, $currentRecord);
            }
            default:
            {
                return null;
            }
        }
    }

}
