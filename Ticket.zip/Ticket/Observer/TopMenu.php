<?php
namespace Movie\Ticket\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Data\Tree\Node;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\UrlInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\App\Cache\Frontend\Pool;
use Magento\Backend\Block\Cache;
/**
 * Class TopMenu
 * @package Magenest\Ticket\Observer
 */
class TopMenu implements ObserverInterface
{
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfigInterface;

    /**
     * @var UrlInterface
     */
    protected $urlInterface;
    /**
     * @var TypeListInterface
     */
    protected $typeListInterface;
    /**
     * @var Pool
     */
    protected $pool;
    /**
     * @var Cache
     */
    protected $cache;

    /**
     * TopMenu constructor.
     * @param ScopeConfigInterface $scopeConfigInterface
     * @param UrlInterface $urlInterface
     */
    public function __construct(
        ScopeConfigInterface    $scopeConfigInterface,
        UrlInterface            $urlInterface,
        TypeListInterface $typeListInterface,
        Pool $pool,
        Cache $cache
    ) {
        $this->scopeConfigInterface=$scopeConfigInterface;
        $this->urlInterface=$urlInterface;
        $this->typeListInterface = $typeListInterface;
        $this->pool = $pool;
        $this->cache=$cache;
    }

    /**
     * @param EventObserver $observer
     * @return $this|void
     */
    public function execute(EventObserver $observer)
    {
        $menu = $observer->getMenu();
        $tree = $menu->getTree();
        $this->cache->getFlushSystemUrl();
        $data = [
            'name'      => 'Coming Soon',
            'id'        => 'event-top-menu-active',
            'url'       => $this->urlInterface->getUrl('ticket/film/coming'),
            'is_active' => false
        ];

        $node = new Node($data, 'id', $tree, $menu);
        $menu->addChild($node);
        return $this;
    }
}
