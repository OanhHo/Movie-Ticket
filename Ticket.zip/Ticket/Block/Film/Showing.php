<?php

namespace Movie\Ticket\Block\Film;

use Movie\Ticket\Model\Film;
use Movie\Ticket\Model\DateSession;
use Movie\Ticket\Model\Room;
use Movie\Ticket\Model\Cinema;
use Magento\Framework\View\Element\Template;

/**
 * Class Showing
 * @package Movie\Ticket\Block\Film
 */
class Showing extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Catalog\Model\ProductRepository
     */
    protected $productRepository;

    /**
     * @var string
     */
    protected $_template = 'film/showing.phtml';
    /**
     * @var \Movie\Ticket\Model\DateSessionFactory
     */
    protected $_dateSession;
    /**
     * @var \Movie\Ticket\Model\FilmFactory
     */
    protected $_filmFactory;
    /**
     * @var \Movie\Ticket\Model\RoomFactory
     */
    protected $_roomFactory;
    /**
     * @var \Movie\Ticket\Model\CinemaFactory
     */
    protected $_cinemaFactory;

    /**
     * Showing constructor.
     * @param Template\Context $context
     * @param \Movie\Ticket\Model\FilmFactory $filmFactory
     * @param \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory
     * @param \Movie\Ticket\Model\RoomFactory $roomFactory
     * @param \Movie\Ticket\Model\CinemaFactory $cinemaFactory
     * @param \Magento\Catalog\Model\ProductRepository $productRepository
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        \Movie\Ticket\Model\FilmFactory $filmFactory,
        \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory,
        \Movie\Ticket\Model\RoomFactory $roomFactory,
        \Movie\Ticket\Model\CinemaFactory $cinemaFactory,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        array $data = []
    ) {
        $this->_filmFactory=$filmFactory;
        $this->_dateSession=$dateSessionFactory;
        $this->_roomFactory=$roomFactory;
        $this->_cinemaFactory=$cinemaFactory;
        $this->productRepository=$productRepository;
        parent::__construct($context, $data);
    }

    /**
     * @param $date
     * @param $time
     * @return \DateTime|false|string
     */
    protected function convertDate($date, $time)
    {
        $date=date_create($date);
        $date=date_format($date, "Y-m-d");
        $date=$date . 'T' . $time . ':00';
        return $date;
    }

    /**
     * @param $date
     * @return \DateTime|false|string
     */
    protected function convertDay($date)
    {
        $date=date_create($date);
        $date=date_format($date, "Y-m-d");
        return $date;
    }

    /**
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getFilmCollection()
    {
        $collection=$this->_filmFactory->create()->getCollection()
            ->addFieldToFilter('enable', 1)
            ->addFieldToFilter('apply_all_schedule', '1');
        $filmArray = [];
        $counter = 0;
        foreach ($collection as $film) {
            /**
             * @var Film $film
             */
            $filmName=$film->getData('film_name');
            $product_id=$film->getData('product_id');
            $this->productRepository->getById($product_id);
            $product = $this->productRepository->getById($product_id);
            $productUrl=$product->getUrlModel()->getUrl($product);
            $inTheater=$film->getData('in_theater');
            $today = date("Y-m-d");
            if ( $today>=$inTheater){
                $dateSession=$this->_dateSession->create()->getCollection()
                    ->addFieldToFilter('product_id', $product_id)
                    ->addFieldToFilter('session_is_enabled', 1);
                foreach ($dateSession as $session) {
                    $roomModel=$this->_roomFactory->create()->getCollection()
                        ->addFieldToFilter('room_id', $session->getRoomId())
                        ->getFirstItem();
                    $cinemaModel=$this->_cinemaFactory->create()->getCollection()
                        ->addFieldToFilter('cinema_id', $roomModel->getCinemaId())
                        ->getFirstItem();
                    $startTime=$session->getData('time');
                    $filmArray[$counter]=[
                        'id'=>$session->getData('session_id'),
                        'url'=>$productUrl,
                        'title'=>$filmName,
                        'cinema'=>$cinemaModel->getName(),
                        'location'=>$cinemaModel->getAddress(),
                        'room'=>$roomModel->getTitle(),
                        'start'=>$this->convertDate($session->getData('date'), $startTime),
                        'end'=>$this->convertDate($session->getData('date'), $startTime),
                    ];
                    $counter++;
                    }
                }
            }

        return $filmArray;
    }
}
