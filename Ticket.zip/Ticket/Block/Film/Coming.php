<?php

namespace Movie\Ticket\Block\Film;

use Movie\Ticket\Model\Film;
use Movie\Ticket\Model\DateSession;
use Magento\Framework\View\Element\Template;

/**
 * Class Coming
 * @package Movie\Ticket\Block\Film
 */
class Coming extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Catalog\Model\ProductRepository
     */
    protected $productRepository;

    /**
     * @var string
     */
    protected $_template = 'film/coming.phtml';
    /**
     * @var \Movie\Ticket\Model\FilmFactory
     */
    protected $_filmFactory;
    /**
     * @var \Movie\Ticket\Model\DateSessionFactory
     */
    protected $_dateSession;

    /**
     * Coming constructor.
     * @param Template\Context $context
     * @param \Movie\Ticket\Model\FilmFactory $filmFactory
     * @param \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory
     * @param \Magento\Catalog\Model\ProductRepository $productRepository
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        \Movie\Ticket\Model\FilmFactory $filmFactory,
        \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        array $data = []
    ) {
        $this->_filmFactory=$filmFactory;
        $this->_dateSession=$dateSessionFactory;
        $this->productRepository=$productRepository;
        parent::__construct($context, $data);
    }

    /**
     * @param $date
     * @param $time
     * @return \DateTime|false|string
     */
    protected function convertDate($date, $time)
    {
        $date=date_create($date);
        $date=date_format($date, "Y-m-d");
        $date=$date . 'T' . $time . ':00';
        return $date;
    }

    /**
     * @param $date
     * @return \DateTime|false|string
     */
    protected function convertDay($date)
    {
        $date=date_create($date);
        $date=date_format($date, "Y-m-d");
        return $date;
    }

    /**
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getFilmCollection()
    {
        $collection=$this->_filmFactory->create()->getCollection()
            ->addFieldToFilter('enable', 1);
        $filmArray = [];
        $counter = 0;
        foreach ($collection as $film) {
            /**
             * @var Film $film
             */
            $filmName=$film->getData('film_name');
            $product_id=$film->getData('product_id');
            $this->productRepository->getById($product_id);
            $product = $this->productRepository->getById($product_id);
            if (isset($product)){
                $productUrl=$product->getUrlModel()->getUrl($product);
                $inTheater=$film->getData('in_theater');
                $today = date("Y-m-d");
                if ($inTheater >$today){
                    $filmArray[$counter]=[
                        'id'=>$film->getData('film_id'),
                        'url'=>$productUrl,
                        'title'=>$filmName,
                        'start_date'=>$this->convertDay($inTheater),
                        'end_date'=>$this->convertDay($inTheater),
                        'runtime'=>$film->getData('runtime'),
                        'genre'=>$film->getData('genre'),
                        'rated'=>$film->getData('rated')
                    ];
                    $counter++;
                }
            }
        }
        return $filmArray;
    }
}
