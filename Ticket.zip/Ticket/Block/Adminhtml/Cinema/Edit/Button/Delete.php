<?php
namespace Movie\Ticket\Block\Adminhtml\Cinema\Edit\Button;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

/**
 * Class Delete
 * @package Movie\Ticket\Block\Adminhtml\Cinema\Edit\Button
 */
class Delete extends \Magento\Framework\View\Element\Template implements ButtonProviderInterface
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlInterface;
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * Delete constructor.
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\UrlInterface $urlInterface
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlInterface,
        array $data = []
    )
    {
        $this->_storeManager = $storeManager;
        $this->_urlInterface = $urlInterface;
        $this->_request=$context->getRequest();
        parent::__construct($context, $data);
    }

    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    /**
     * Prining URLs using URLInterface
     */
    public function getButtonData()
    {
        return [
            'label' => __('Delete '),
            'on_click' => 'deleteConfirm(\'' . __('Are you sure you want to delete this cinema ?') . '\', \'' . $this->getDeleteUrl() . '\')',
            'class' => 'delete',
            'sort_order' => 20
        ];
    }

    /**
     * @return string
     */
    public function getDeleteUrl() {
        $id = $this->_request->getParam('cinema_id');
        return $this->getUrl('*/*/newDelete', array('cinema_id'=>$id));
    }

}