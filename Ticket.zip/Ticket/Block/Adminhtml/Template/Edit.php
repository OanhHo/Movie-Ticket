<?php
namespace Movie\Ticket\Block\Adminhtml\Template;

use Magento\Backend\Block\Widget\Form\Container;

/**
 * Class Edit
 * @package Movie\Ticket\Block\Adminhtml\Template
 */
class Edit extends Container
{
    /**
     * Core registry
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_objectId   = 'template_id';
        $this->_blockGroup = 'Movie_Ticket';
        $this->_controller = 'adminhtml_template';
        parent::_construct();

        $this->buttonList->update('save', 'label', __('Save'));
        $this->buttonList->remove('delete');
    }

    /**
     * Get edit form container header text
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('ticket_template')->getTemplateId()) {
            return __("Template %1", $this->_coreRegistry->registry('ticket_template')->getTitle());
        } else {
            return __('New Template');
        }
    }

    /**
     * @return string
     */
    public function getBackUrl()
    {
        return $this->getUrl('*/*/');
    }
}
