<?php

namespace Movie\Ticket\Block\Adminhtml\Template\Edit\Button;

use Magento\Backend\Block\Widget\Context;
use Magento\Cms\Api\PageRepositoryInterface;
use Magento\Cms\Block\Adminhtml\Page\Edit\GenericButton;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

/**
 * Class PrintPDF
 * @package Movie\Ticket\Block\Adminhtml\Template\Edit\Button
 */
class PrintPDF extends GenericButton implements ButtonProviderInterface
{
    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $_messageManager;
    /**
     * Url Builder
     *
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $request;


//    public function __construct(\Magento\Backend\Block\Widget\Context $context,
//                                \Magento\Framework\Message\ManagerInterface $messageManager)
//    {
//        $this->_messageManager=$messageManager;
//        $this->request = $context->getRequest();
//        $this->urlBuilder = $context->getUrlBuilder();
//    }
    /**
     * PrintPDF constructor.
     * @param Context $context
     * @param PageRepositoryInterface $pageRepository
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     */
    public function __construct(Context $context, PageRepositoryInterface $pageRepository,
                                \Magento\Framework\Message\ManagerInterface $messageManager)
    {
        $this->_messageManager=$messageManager;
        $this->request = $context->getRequest();
        $this->urlBuilder = $context->getUrlBuilder();
        parent::__construct($context, $pageRepository);
    }

    /**
     * @return array
     */
    public function getButtonData()
    {
        $data = [
            'label' => __('Print PDF'),
            'on_click' => (!empty($this->request->getParam("template_id")) ? sprintf("location.href = '%s';", $this->getPrintUrl()) : sprintf('$s',$this->_messageManager->addNotice(__("You must be save new template before print PDF")))),
            'sort_order' => 80,
        ];

        return $data;
    }

    /**
     * @return string
     */
    protected function getPrintUrl()
    {
        return $this->getUrl('*/*/printTicket', ['id' => $this->request->getParam("template_id")]);
    }

    /**
     * @param string $route
     * @param array $params
     * @return string
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->urlBuilder->getUrl($route, $params);
    }
}
