<?php
namespace Movie\Ticket\Block\Adminhtml\Room;

use Magento\Backend\Block\Widget\Form\Container;

/**
 * Class Edit
 * @package Movie\Ticket\Block\Adminhtml\Room
 */
class Edit extends Container
{
    /**
     * Core registry
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_objectId   = 'room_id';
        $this->_blockGroup = 'Movie_Ticket';
        $this->_controller = 'adminhtml_room';
        parent::_construct();

        $this->buttonList->update('save', 'label', __('Save'));
        $this->buttonList->remove('delete');
    }

    /**
     * Get edit form container header text
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('ticket_room')->getRoomId()) {
            return __("Room %1", $this->_coreRegistry->registry('ticket_room')->getTitle());
        } else {
            return __('New Room');
        }
    }

    /**
     * @return string
     */
    public function getBackUrl()
    {
        return $this->getUrl('*/*/');
    }
}
