<?php
namespace Movie\Ticket\Block\Adminhtml\Room\Edit\Button;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class Delete extends \Magento\Framework\View\Element\Template implements ButtonProviderInterface
{
    protected $_storeManager;
    protected $_urlInterface;
    protected $_request;
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlInterface,
        array $data = []
    )
    {
        $this->_storeManager = $storeManager;
        $this->_urlInterface = $urlInterface;
        $this->_request=$context->getRequest();
        parent::__construct($context, $data);
    }

    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    /**
     * Prining URLs using URLInterface
     */
    public function getButtonData()
    {
        return [
            'label' => __('Delete '),
            'on_click' => 'deleteConfirm(\'' . __('Are you sure you want to delete this room ?') . '\', \'' . $this->getDeleteUrl() . '\')',
            'class' => 'delete',
            'sort_order' => 20
        ];
    }

    public function getDeleteUrl() {
        $id = $this->_request->getParam('room_id');
        return $this->getUrl('*/*/newDelete', array('room_id'=>$id));
    }

}