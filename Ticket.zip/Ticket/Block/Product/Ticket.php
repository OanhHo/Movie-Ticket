<?php

namespace Movie\Ticket\Block\Product;
/**
 * Class Ticket
 * @package Movie\Ticket\Block\Product
 */
class Ticket extends \Magento\Framework\View\Element\Template
{
    /**
     * Google Map API key
     */
    const XML_PATH_GOOGLE_MAP_API_KEY = 'movie_ticket/general_config/google_api_key';

    /**
     * Is tax included in PDP display prices
     */
    const XML_PATH_SHOW_TAX_INCLUDE = 'tax/display/type';

    /**
     * @var \Magento\Directory\Model\Currency
     */
    protected $_currency;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Magento\Framework\Locale\FormatInterface
     */
    protected $_format;

    /**
     * @var \Magento\Tax\Api\TaxCalculationInterface
     */
    protected $_taxCalculation;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $datetime;

    protected $basePrice;
    /**
     * @var \Movie\Ticket\Model\FilmFactory
     */
    protected $_filmFactory;
    /**
     * @var \Movie\Ticket\Model\CinemaFactory
     */
    protected $_cinema;
    /**
     * @var \Movie\Ticket\Model\RoomFactory
     */
    protected $room;
    /**
     * @var \Movie\Ticket\Model\DateSessionFactory
     */
    protected $session;


    /**
     * Ticket constructor.
     * @param \Magento\Catalog\Block\Product\Context $context
     * @param \Movie\Ticket\Model\FilmFactory $filmFactory
     * @param \Movie\Ticket\Model\CinemaFactory $cinemaFactory
     * @param \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory
     * @param \Movie\Ticket\Model\RoomFactory $roomFactory
     * @param \Magento\Directory\Model\Currency $currency
     * @param \Magento\Framework\Locale\FormatInterface $format
     * @param \Magento\Tax\Api\TaxCalculationInterface $taxCalculation
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $dateTime
     * @param array $data
     */
    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Movie\Ticket\Model\FilmFactory $filmFactory,
        \Movie\Ticket\Model\CinemaFactory $cinemaFactory,
        \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory,
        \Movie\Ticket\Model\RoomFactory $roomFactory,
        \Magento\Directory\Model\Currency $currency,
        \Magento\Framework\Locale\FormatInterface $format,
        \Magento\Tax\Api\TaxCalculationInterface $taxCalculation,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $dateTime,
        array $data
    ) {
        $this->_filmFactory        = $filmFactory;
        $this->_cinema            = $cinemaFactory;
        $this->session         = $dateSessionFactory;
        $this->room          = $roomFactory;
        $this->_coreRegistry   = $context->getRegistry();
        $this->_format         = $format;
        $this->_taxCalculation = $taxCalculation;
        $this->datetime        = $dateTime;
        parent::__construct($context, $data);
    }

    /**
     * @return mixed
     */
    public function getCurrentProductId()
    {
        return $this->_coreRegistry->registry('current_product')->getId();
    }

    /**
     * @return mixed
     */
    public function getFilm()
    {
        return $this->_filmFactory->create()->getCollection()
            ->addFieldToFilter('product_id',$this->getCurrentProductId())
            ->getFirstItem();
    }

    /**
     * @return false|string
     */
    public function getPriceFormatArray()
    {
        return json_encode($this->_format->getPriceFormat());
    }

    /**
     * @return float|int
     */
    public function getTaxRate()
    {
        if ($this->_scopeConfig->getValue(self::XML_PATH_SHOW_TAX_INCLUDE) == 2
            || $this->_scopeConfig->getValue(self::XML_PATH_SHOW_TAX_INCLUDE) == 3) {
            $defaultRate = $this->_taxCalculation->getCalculatedRate($this->_coreRegistry->registry('current_product')->getTaxClassId());

            return 1 + ($defaultRate / 100);
        }

        return 1;
    }

    /**
     * @return mixed
     */
    public function getBasePrice()
    {
        return isset($this->basePrice) ? $this->basePrice : $this->_coreRegistry->registry('current_product')->getPrice();
    }

    /**
     * @return bool
     */
    public function isFilmTicketProduct()
    {
        $product = $this->_coreRegistry->registry('current_product');
        $film   = $this->_filmFactory->create()->getCollection()->addFieldToFilter(
            'product_id',
            $product->getId()
        )->getFirstItem();
        if ($film->getFilmId()) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * Get formatted price string
     *
     * @param $price
     * @param $taxRate
     *
     * @return string
     */
    public function getOptionTypePriceString($price, $taxRate)
    {
        return $this->_currency->format($price * $taxRate);
    }

    /**
     *
     * @param $title
     * @param $address
     *
     * @return \Magento\Framework\Phrase|string
     */
    public function getOptionTypeLocation($title, $address)
    {
        if (empty($title) && empty($address)) {
            return '';
        } elseif (empty($title) && !empty($address)) {
            return __(' (%1)', $address);
        } elseif (empty($address) && !empty($title)) {
            return __(' (%1)', $title);
        } else {
            return __(' (%1, %2)', $title, $address);
        }
    }

    /**
     * @return mixed
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCurrencySymbol()
    {
        return $this->_storeManager->getStore()->getBaseCurrency()->getCurrencySymbol();

    }
    /**
     * @return mixed
     */
    public function getSchedule()
    {
        return $this->_filmFactory->create()->getCollection()
            ->addFieldToFilter('product_id',$this->getCurrentProductId())
            ->getFirstItem();

    }

    /**
     * Get Google Map Api key
     * @return mixed
     */
    public function getGoogleApiKey()
    {
        return $this->_scopeConfig->getValue(self::XML_PATH_GOOGLE_MAP_API_KEY);
    }

    /**
     * @return \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
     */
    public function getCinema()
    {
        $modelCinema = $this->_cinema->create()->getCollection()
            ->addFieldToFilter('enabled', 1);

        return $modelCinema;
    }

    public function canChooseLocation()
    {
        $film = $this->getFilm();

        if ($film->getApplyAllSchedule() == 0) {
            return false;
        }

        return true;
    }

    public function isOptionOutOfDate($startDate, $endDate, $showLocations = 0)
    {
        if ($showLocations == 1) {
            return false;
        }

        $now = strtotime($this->datetime->date()->format('Y-m-d H:i:s'));
        if (empty($startDate) && empty($endDate)) {
            return false;
        } elseif (isset($endDate) && $now > strtotime($endDate)) {
            return true;
        }

        return false;
    }

    /**
     * @param $cinemaId
     * @return mixed
     */
    public function getRoom($cinemaId)
    {
        $room = $this->room->create()->getCollection()
            ->addFieldToFilter('cinema_id', $cinemaId)
            ->addFieldToFilter('enabled', 1);
        return $room;
    }

    /**
     * @param $dateId
     *
     * @return \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
     */
    public function getSession($roomId)
    {
        $session = $this->session->create()->getCollection()
            ->addFieldToFilter('room_id', $roomId)
            ->addFieldToFilter('product_id', $this->getCurrentProductId())
            ->addFieldToFilter('session_is_enabled', 1);

        return $session;
    }

    /**
     * @return string
     */
    public function getLayoutSingle()
    {
        $layout = $this->_layout->createBlock('Movie\Ticket\Block\Product\Single');

        return $layout->toHtml();
    }


    /**
     * @return string
     */
    public function getReturnSession()
    {
        return $this->getUrl('ticket/order/session');
    }

    /**
     * @return bool
     */
    public function isRegisterRequired()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $film         = $objectManager->create('\Movie\Ticket\Model\FilmFactory');
        $context       = $objectManager->create('\Magento\Catalog\Block\Product\Context');
        $product       = $context->getRegistry()->registry('current_product');
        $film         = $film->create()->getCollection()->addFieldToFilter('product_id', $product->getId())->getFirstItem();
        if ($film->getFilmId()) {
            if ($film->getIsRegisterRequired() == 1) {
                return true;
            }
        }

        return false;
    }
}
