<?php

namespace Movie\Ticket\Block\Product;

/**
 * Class Single
 * @package Movie\Ticket\Block\Product
 */
class Single extends \Magento\Framework\View\Element\Template
{
    /**
     * @var string
     */
    protected $_dateInLocations = [];
    protected $_sessionsInDate = [];
    protected $_template = 'catalog/product/single.phtml';

    /**
     * Date format
     */
    const XML_PATH_DATE_FORMAT = 'event_ticket/general_config/date_format';

    const XML_PATH_ADD_TO_CALENDAR = 'event_ticket/general_config/add_to_calendar';

    /**
     * Auto hide expired dates based on end date
     */
    const XML_PATH_HIDE_EXPIRED = 'event_ticket/general_config/hide_expired';

    /**
     * Load maps on product page or not
     */
    const XML_PATH_MAP_ENABLED = 'event_ticket/general_config/google_map';

    /**
     * Google Map API key
     */
    const XML_PATH_GOOGLE_MAP_API_KEY = 'event_ticket/general_config/google_api_key';

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_currency;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Magenest\Ticket\Model\EventLocationFactory
     */
    protected $location;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $_datetime;
    /**
     * @var \Movie\Ticket\Model\FilmFactory
     */
    protected $_filmFactory;
    /**
     * @var \Movie\Ticket\Model\CinemaFactory
     */
    protected $_cinema;
    /**
     * @var \Movie\Ticket\Model\RoomFactory
     */
    protected $room;
    /**
     * @var \Movie\Ticket\Model\DateSessionFactory
     */
    protected $session;


    /**
     * Single constructor.
     * @param \Magento\Catalog\Block\Product\Context $context
     * @param \Movie\Ticket\Model\FilmFactory $filmFactory
     * @param \Movie\Ticket\Model\CinemaFactory $cinemaFactory
     * @param \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory
     * @param \Movie\Ticket\Model\RoomFactory $roomFactory
     * @param \Magento\Directory\Model\Currency $currency
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $datetime
     * @param array $data
     */
    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Movie\Ticket\Model\FilmFactory $filmFactory,
        \Movie\Ticket\Model\CinemaFactory $cinemaFactory,
        \Movie\Ticket\Model\DateSessionFactory $dateSessionFactory,
        \Movie\Ticket\Model\RoomFactory $roomFactory,
        \Magento\Directory\Model\Currency $currency,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $datetime,
        array $data = []
    ) {
        $this->_filmFactory        = $filmFactory;
        $this->_cinema            = $cinemaFactory;
        $this->session         = $dateSessionFactory;
        $this->room          = $roomFactory;
        $this->_currency     = $currency;
        $this->_datetime     = $datetime;
        $this->_coreRegistry = $context->getRegistry();
        parent::__construct($context, $data);
    }

    /**
     * @return mixed
     */
    public function getCurrentProductId()
    {
        $id = $this->_coreRegistry->registry('current_product')->getId();

        return $id;
    }

    /**
     * @return bool
     */
    public function isMapEnabled()
    {
        $isEnabled = $this->_scopeConfig->getValue(self::XML_PATH_MAP_ENABLED);
        if ($this->_scopeConfig->getValue(self::XML_PATH_MAP_ENABLED)) {
            return true;
        }
        return false;

    }

    /**
     * Get Google Map Api key
     * @return mixed
     */
    public function getGoogleApiKey()
    {
        return $this->_scopeConfig->getValue(self::XML_PATH_GOOGLE_MAP_API_KEY);
    }

    public function isEnabelAddToCalendar()
    {
        return $this->_scopeConfig->getValue(self::XML_PATH_ADD_TO_CALENDAR);
    }

    /**
     * @return \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
     */
    public function getCinema()
    {
        $modelCinema = $this->_cinema->create()->getCollection()
            ->addFieldToFilter('enabled', 1);

        return $modelCinema;
    }

    /**
     * @param $cinemaId
     * @return mixed
     */
    public function getRoom($cinemaId)
    {
        if (!isset($this->_roomCinema[$cinemaId])) {
            $this->_roomCinema[$cinemaId] = $this->_cinema->create()->getCollection()
                ->addFieldToFilter('cinemaId', $cinemaId)
                ->addFieldToFilter('enabled', 1);
        }
        return $this->_roomCinema[$cinemaId];
    }

    /**
     * @param $dateId
     *
     * @return $this
     */
    public function getSession($roomID)
    {
        if (!isset($this->_sessionsInRoom[$roomID])) {
            $this->_sessionsInRoom[$roomID] = $this->session->create()->getCollection()
                ->addFieldToFilter('room_id', $roomID)
                ->addFieldToFilter('product_id',$this->getCurrentProductId())
                ->addFieldToFilter('session_is_enabled', 1);
        }

        return $this->_sessionsInRoom[$roomID];
    }

    /**
     * @return string
     */
    public function getReturnSession()
    {
        return $this->getUrl('ticket/order/session');
    }

    /**
     * @return \Magento\Framework\DataObject
     */
    public function getFilm()
    {
        return $this->_filmFactory->create()->getCollection()
            ->addFieldToFilter('product_id',$this->getCurrentProductId())
            ->getFirstItem();
    }

    /**
     * @return mixed
     */
    public function getDateFormat()
    {
        return $this->_scopeConfig->getValue(self::XML_PATH_DATE_FORMAT);

    }
    
    /**
     * @param $dateId
     * @return int|void
     * Check session is not enable
     */
    public function getSessionNotEnable($roomId)
    {
        if (!isset($this->_sessionsInRoom[$roomId])) {
            $sessionOption= $this->session->create()->getCollection()
                ->addFieldToFilter('room_id', $roomId);
        }
        $sizeofSession=count($sessionOption);
        if ($sizeofSession<=0) {
            $checkAllSession=1;
        } else {
            $checkAllSession=$sizeofSession;
            foreach ($sessionOption as $session) {
                /**
                 * @var \Magenest\Ticket\Model\EventSession $session
                 */
                $sessionIsEnable=$session->getSessionIsEnabled();
                if ($sessionIsEnable==0) {
                    $checkAllSession --;
                }
            }
            if ($checkAllSession>0) {
                $checkAllSession=1;
            } else {
                $checkAllSession=0;
            }
        }
        return $checkAllSession;
    }
}
