<?php

namespace Movie\Ticket\Block\Product\Tab;

/**
 * Class Terms
 * @package Movie\Ticket\Block\Product\Tab
 */
class Terms extends \Magento\Catalog\Block\Product\View\Description
{

    /**
     * @var \Magento\Cms\Model\Template\FilterProvider
     */
    protected $_filter;
    /**
     * @var \Movie\Ticket\Model\FilmFactory
     */
    protected $_filmFactory;

    /**
     * Terms constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Movie\Ticket\Model\FilmFactory $filmFactory
     * @param \Magento\Cms\Model\Template\FilterProvider $filterProvider
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Movie\Ticket\Model\FilmFactory $filmFactory,
        \Magento\Cms\Model\Template\FilterProvider $filterProvider,
        array $data = []
    ) {
        $this->_filter       = $filterProvider;
        $this->_filmFactory = $filmFactory;
        parent::__construct($context, $registry, $data);
    }

    /**
     * @return string|null
     * @throws \Exception
     */
    public function getTerms()
    {
        $productId = $this->getRequest()->getParam('id');
        $event     = $this->_filmFactory->create()->loadByProductId($productId);
        if (!empty($event) && $event->getId()) {
            if (!empty($terms = $event->getTerm()))
                return $this->_filter->getPageFilter()->filter($terms);
        }

        return null;
    }
}
