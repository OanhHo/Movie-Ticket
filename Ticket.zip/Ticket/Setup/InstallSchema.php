<?php
/**
 * Copyright © 2018 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Movie\Ticket\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema
 * @package Magenest\Ticket\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * install tables
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @throws \Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        if (!$installer->tableExists($installer->getTable('movie_ticket'))) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable('movie_ticket')
            )->addColumn(
                'ticket_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'nullable' => false,
                    'primary' => true,
                    'unsigned' => true,
                ],
                'Ticket ID'
            )->addColumn(
                'film_id',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => false],
                'Ticket Film Id'
            )->addColumn(
                'title',
                Table::TYPE_TEXT,
                50,
                ['nullable' => true],
                'Ticket Title'
            )->addColumn(
                'code',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Ticket Code'
            )->addColumn(
                'customer_name',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Ticket Customer Name'
            )->addColumn(
                'customer_email',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Ticket Customer Email'
            )->addColumn(
                'customer_id',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => true],
                'Ticket Customer Id'
            )->addColumn(
                'order_id',
                Table::TYPE_INTEGER,
                10,
                ['nullable' => false],
                'Ticket Order  Id'
            )->addColumn(
                'order_increment_id',
                Table::TYPE_TEXT,
                32,
                ['nullable' => true],
                'Ticket Order Increment Id'
            )->addColumn(
                'order_item_id',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => false],
                'Ticket Order Item Id'
            )->addColumn(
                'status',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => true, 'default' => 0],
                'Ticket Order Item Id'
            )->addColumn(
                'created_at',
                Table::TYPE_TIMESTAMP,
                null,
                [],
                'Ticket Created At'
            )->addColumn(
                'updated_at',
                Table::TYPE_TIMESTAMP,
                null,
                [],
                'Ticket Updated At'
            )->addColumn(
                'product_id',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => true],
                'Ticket Product Id'
            )->addColumn(
                'information',
                Table::TYPE_TEXT,
                null,
                ['nullable' => true],
                'Ticket Information'
            )->addColumn(
                'qty',
                Table::TYPE_TEXT,
                11,
                ['nullable' => false],
                'Ticket Qty'
            )->addColumn(
                'remind',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => true],
                'Ticket Remind'
            )->addColumn(
                'date_id',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => false],
                'Ticket Date'
            )->addColumn(
                'location_id',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => false],
                'Ticket Location Id'
            )->addColumn(
                'product_id',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => false],
                'Ticket Product Id'
            )->addColumn(
                'session_id',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => false],
                'Ticket DateSession Id'
            )->setComment('Ticket Table');
            $installer->getConnection()->createTable($table);

            $installer->getConnection()->addIndex(
                $installer->getTable('movie_ticket'),
                $setup->getIdxName(
                    $installer->getTable('movie_ticket'),
                    ['customer_name', 'customer_email'],
                    AdapterInterface::INDEX_TYPE_FULLTEXT
                ),
                ['customer_name', 'customer_email'],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            );
        }

        if (!$installer->tableExists($installer->getTable('movie_film'))) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable('movie_film')
            )->addColumn(
                'film_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'nullable' => false,
                    'primary' => true,
                    'unsigned' => true,
                ],
                'Film ID'
            )->addColumn(
                'product_id',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Film Product Id'
            )->addColumn(
                'film_name',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Film Name'
            )->addColumn(
                'enable',
                Table::TYPE_TEXT,
                255,
                ['nullable' => true],
                'Film Status'
            )->addColumn(
                'allow_generate_pdf_ticket',
                Table::TYPE_INTEGER,
                null,
                [],
                'Film Allow Generate PDF Ticket'
            )->addColumn(
                'created_at',
                Table::TYPE_TIMESTAMP,
                null,
                [],
                'Film Created At'
            )->addColumn(
                'updated_at',
                Table::TYPE_TIMESTAMP,
                null,
                [],
                'Film Updated At'
            )->addColumn(
                'enable_date_time',
                Table::TYPE_INTEGER,
                null,
                [],
                'Film Date Status'
            )->addColumn(
                'allow_register',
                Table::TYPE_INTEGER,
                null,
                [],
                'Film Allow Register'
            )->addColumn(
                'is_register_reqired',
                Table::TYPE_INTEGER,
                null,
                [],
                'Film Register Required'
            )->addColumn(
                'template_id',
                Table::TYPE_INTEGER,
                null,
                [],
                'Film Template Id'
            )->addColumn(
                'use_customer_template',
                Table::TYPE_DECIMAL,
                null,
                [],
                'Film Use Customer Template'
            )->addColumn(
                'apply_all_schedule',
                Table::TYPE_INTEGER,
                null,
                [],
                'Film Apply All Schedule'
            )->setComment('Film Table');
            $installer->getConnection()->createTable($table);

            $installer->getConnection()->addIndex(
                $installer->getTable('movie_film'),
                $setup->getIdxName(
                    $installer->getTable('movie_film'),
                    ['product_id', 'film_name', 'enable'],
                    AdapterInterface::INDEX_TYPE_FULLTEXT
                ),
                ['product_id', 'film_name', 'enable'],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            );
        }
        if (!$installer->tableExists($installer->getTable('movie_ticket_template'))) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable('movie_ticket_template')
            )->addColumn(
                'template_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'nullable' => false,
                    'primary' => true,
                    'unsigned' => true,
                ],
                'Template ID'
            )->addColumn(
                'enable',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => false],
                'Template Enable'
            )->addColumn(
                'pdf_coordinates',
                Table::TYPE_TEXT,
                '64K',
                [],
                'PDF Ticket Coordinates'
            )->addColumn(
                'pdf_page_width',
                Table::TYPE_INTEGER,
                null,
                [],
                'PDF Ticket Page Width'
            )->addColumn(
                'pdf_page_height',
                Table::TYPE_INTEGER,
                null,
                [],
                'PDF Ticket Page Height'
            )->addColumn(
                'pdf_background',
                Table::TYPE_TEXT,
                null,
                [],
                'PDF Ticket Background'
            )->setComment('Movie Ticket Template');
            $installer->getConnection()->createTable($table);
        }

        if (!$installer->tableExists($installer->getTable('movie_room'))) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable('movie_room')
            )->addColumn(
                'room_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'nullable' => false,
                    'primary' => true,
                    'unsigned' => true,
                ],
                'Room ID'
            )->addColumn(
                'title',
                Table::TYPE_TEXT,
                50,
                ['nullable' => true],
                'Room Title '
            )->setComment('Movie Room');
            $installer->getConnection()->createTable($table);
        }
        if (!$installer->tableExists($installer->getTable('movie_date'))) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable('movie_date')
            )->addColumn(
                'date_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'nullable' => false,
                    'primary' => true,
                    'unsigned' => true,
                ],
                'Date ID'
            )->addColumn(
                'date_is_enabled',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => false],
                'Date Is Enabled'
            )->setComment('Movie Date');
            $installer->getConnection()->createTable($table);
        }

        $installer->endSetup();
    }
}
