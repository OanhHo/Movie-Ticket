<?php

namespace Movie\Ticket\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class UpgradeSchema
 * @package Movie\Ticket\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        if (version_compare($context->getVersion(), '2.0.2') < 0) {
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_ticket_template'),
                'title',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 50,
                    'nullable' => false,
                    'comment' => 'Template Title'
                ]
            );
        }
        if (version_compare($context->getVersion(), '2.0.3') < 0) {
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_room'),
                'detail',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => false,
                    'comment' => 'Room Detail'
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_room'),
                'enabled',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    'length' => 11,
                    'nullable' => false,
                    'comment' => 'Room Enable'
                ]
            );
        }

        //add Film Columns
        if (version_compare($context->getVersion(),'2.0.5')){
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'cinema_id',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    'length' => 11,
                    'nullable' => false,
                    'comment' => 'Film Cinema Id'
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'genre',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 100,
                    'nullable' => true,
                    'comment' => 'Film Genre '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'cast',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 256,
                    'nullable' => true,
                    'comment' => 'Film Cast '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'director',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 256,
                    'nullable' => true,
                    'comment' => 'Film Director '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'in_theater',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATE,
                    'length' => null,
                    'nullable' => true,
                    'comment' => 'Film In Theater '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'runtime',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 11,
                    'nullable' => true,
                    'comment' => 'Film Runtime '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'rated',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => true,
                    'comment' => 'Film Rated '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'detail',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => true,
                    'comment' => 'Film Detail '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'trailer',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => true,
                    'comment' => 'Film Trailer '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_film'),
                'term',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => true,
                    'comment' => 'Film Term '
                ]
            );
        }
        if(version_compare($context->getVersion(),'2.0.7')){
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_room'),
                'cinema_id',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    'length' => 11,
                    'nullable' => false,
                    'comment' => 'Room Cinema Id'
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_room'),
                'date',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATE,
                    'length' => 11,
                    'nullable' => false,
                    'comment' => 'Room Date '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_room'),
                'session',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => false,
                    'comment' => 'Room DateSession '
                ]
            );
            $this->createCinemaTable($installer);

        }
        if(version_compare($context->getVersion(),'2.0.9')){
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_date'),
                'room_id',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    'length' => 11,
                    'nullable' => false,
                    'comment' => 'Date Room Id'
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_date'),
                'date_start',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATE,
                    'length' => 11,
                    'nullable' => false,
                    'comment' => 'Date Start '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_date'),
                'date_end',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATE,
                    'length' => 11,
                    'nullable' => false,
                    'comment' => 'Date End '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_date'),
                'session',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => false,
                    'comment' => 'Date Room DateSession '
                ]
            );
            $setup->getConnection()->addColumn(
                $setup->getTable('movie_date'),
                'date_session',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => false,
                    'comment' => 'Date  DateSession '
                ]
            );
        }
        if (version_compare($context->getVersion(),'2.0.14')){
            $this->createDateSessionTable($installer);
        }

    }

    /**
     * @param $installer
     */
    private function createCinemaTable($installer)
    {
        $tableName = $installer->getTable('movie_cinema');

        if ($installer->tableExists($tableName)) {
            return;
        }
        $table = $installer->getConnection()->newTable(
            $installer->getTable($tableName)
        )->addColumn(
            'cinema_id',
            Table::TYPE_INTEGER,
            null,
            [
                'identity' => true,
                'nullable' => false,
                'primary' => true,
                'unsigned' => true,
            ],
            'Cinema ID'
        )->addColumn(
            'name',
            Table::TYPE_TEXT,
            '100',
            [],
            'Cinema Name'
        )->addColumn(
            'address',
            Table::TYPE_TEXT,
            '256',
            [],
            'Cinema Address'
        )->addColumn(
            'enabled',
            Table::TYPE_INTEGER,
            '11',
            [],
            ' Is Enabled '
        );

        $installer->getConnection()->createTable($table);

    }

    /**
     * @param $installer
     */
    private function createDateSessionTable($installer)
    {
        $tableName = $installer->getTable('movie_date_session');

        if ($installer->tableExists($tableName)) {
            return;
        }
        $table = $installer->getConnection()->newTable(
            $installer->getTable($tableName)
        )->addColumn(
            'session_id',
            Table::TYPE_INTEGER,
            null,
            [
                'identity' => true,
                'nullable' => false,
                'primary' => true,
                'unsigned' => true,
            ],
            'DateSession ID'
        )->addColumn(
            'product_id',
            Table::TYPE_INTEGER,
            '11',
            [],
            'Product Id'
        )->addColumn(
            'date_id',
            Table::TYPE_INTEGER,
            '11',
            [],
            'Date Id'
        )->addColumn(
            'room_id',
            Table::TYPE_INTEGER,
            '11',
            [],
            'Room Id'
        )->addColumn(
            'cinema_id',
            Table::TYPE_INTEGER,
            '11',
            [],
            'Cinema Id'
        )->addColumn(
            'date',
            Table::TYPE_DATE,
            '256',
            [],
            'DateSession Time'
        )->addColumn(
            'time',
            Table::TYPE_TEXT,
            '256',
            [],
            'DateSession Time'
        )->addColumn(
            'qty',
            Table::TYPE_INTEGER,
            '11',
            [],
            ' Session Qty '
        )->addColumn(
            'qty_purchase',
            Table::TYPE_INTEGER,
            '11',
            [],
            ' Session Qty Purchase'
        )->addColumn(
            'session_is_enabled',
            Table::TYPE_INTEGER,
            '11',
            [],
            ' DateSession Is Enabled '
        );

        $installer->getConnection()->createTable($table);

    }

}
